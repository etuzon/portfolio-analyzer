"""Read saved financial evidence only; stdout is a credentials-free research fixture."""
import hashlib
import json
import sqlite3
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from app.local_portfolio import LocalPortfolioStore


class ReadOnlyStore(LocalPortfolioStore):
    def __init__(self, path):
        self.path = Path(path)

    def _connect(self):
        connection = sqlite3.connect(f"file:{self.path}?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        return connection


root = Path('/app/data')
store = ReadOnlyStore(root / 'local-portfolio.sqlite3')
before = store.change_token()
cache_bytes = (root / 'portfolio-analysis-cache.json').read_bytes()
cache = json.loads(cache_bytes)
tables = ['funds', 'fund_amount_history', 'price_history', 'manual_securities',
          'security_exposure_profiles', 'security_industry_overrides', 'account_snapshots']
with store._connect() as connection:
    tables_data = {name: [dict(row) for row in connection.execute(f'SELECT * FROM {name}')]
                   for name in tables}
    observations = [json.loads(row[0]) for row in connection.execute(
        "SELECT value FROM app_preferences WHERE key LIKE 'risk_history_v1:%'")]
    client_row = connection.execute("SELECT value FROM app_preferences WHERE key='client_state'").fetchone()
    client = json.loads(client_row[0]) if client_row else {}
accounts = store.list_accounts()
transactions = store.list_transactions()
ledger_items = [asdict(item) for item in store.holdings()]
with sqlite3.connect(f"file:{root / 'market-cache.sqlite3'}?mode=ro", uri=True) as connection:
    fx = [{'provider': row[0], 'pair': row[1], 'updated_at': row[2], 'quote': json.loads(row[3])}
          for row in connection.execute("SELECT provider,symbol,updated_at,value FROM security_snapshot WHERE data_type='fx'")]
after = store.change_token()
if before != after or cache_bytes != (root / 'portfolio-analysis-cache.json').read_bytes():
    raise RuntimeError('Source changed during capture; retry')
signature_matches = cache['signature'].split(':')[1] == before
for account in accounts:
    account.pop('comments', None)
    account.pop('username', None)
    for person in account.get('persons', []):
        for key in list(person):
            if key not in {'age', 'birth_date', 'retire_age', 'share_percent'}:
                person.pop(key, None)
for table, rows in tables_data.items():
    for row in rows:
        if table != 'price_history':
            row.pop('comments', None)
        row.pop('persons', None)
for transaction in transactions:
    transaction.pop('comments', None)
    transaction.pop('username', None)
items = []
fields = {'holding', 'price_ranges', 'industry', 'industry_source', 'exposure_profile',
          'missing', 'market_data', 'valuation_price_provider', 'analytics_state'}
for item in cache['payload']['items']:
    clean = {key: value for key, value in item.items() if key in fields}
    clean['holding']['account'] = next((account['management_company'] + ' · ' + account['account_id'][-4:]
                                      for account in accounts if account['id'] == clean['holding'].get('account_id')), '')
    items.append(clean)
print(json.dumps({'captured_at': datetime.now(timezone.utc).isoformat(),
                  'source_signature': cache['signature'], 'source_unchanged_during_capture': True,
                  'ledger_change_token': before, 'cache_signature_matches_ledger': signature_matches,
                  'cache_sha256': hashlib.sha256(cache_bytes).hexdigest(),
                  'cache_expires_at': cache['expires_at'], 'refresh_state': cache['payload'].get('refresh_state'),
                  'base_currency': 'ILS', 'accounts': accounts, 'transactions': transactions,
                  'items': items, 'fx_saved': fx, 'tables': tables_data,
                  'ledger_items': ledger_items,
                  'risk_observations': observations,
                  'client_state_keys': list(client)}, ensure_ascii=False, allow_nan=False))
