const fs=require('fs');const state={baseCurrency:'ILS',fxRates:{},coreFxRates:{},bannerFxRates:{},localAccounts:[],localTransactions:[],language:'en'};
const fmt=(n,d=1)=>Number(n).toFixed(d);const optionLabel=s=>s;
function sum(values) {
  return values.reduce((total, value) => total + Number(value || 0), 0);
}
function normalizedField(item, field) {
  const h = item.holding;
  const value = Number(h[field] || 0);
  const currency = h.currency || state.baseCurrency;
  if (currency === state.baseCurrency) return value;
  const direct = state.fxRates[`${currency}/${state.baseCurrency}`];
  if (direct) return value * direct;
  const reverse = state.fxRates[`${state.baseCurrency}/${currency}`];
  if (reverse) return value / reverse;
  return value;
}
function normalizedAmount(value, currency) {
  const number = Number(value || 0);
  if (!currency || currency === state.baseCurrency) return number;
  const direct = state.fxRates[`${currency}/${state.baseCurrency}`];
  if (direct) return number * direct;
  const reverse = state.fxRates[`${state.baseCurrency}/${currency}`];
  if (reverse) return number / reverse;
  return number;
}
function updateFxRates() {
  state.fxRates = { ...(state.coreFxRates || {}), ...(state.bannerFxRates || {}) };
}
function setCoreFxRates(data) {
  state.coreFxRates = (data?.quotes || []).reduce((rates, item) => {
    const rate = Number(item?.quote?.rate || 0);
    if (item?.pair && rate > 0) rates[item.pair] = rate;
    return rates;
  }, {});
  updateFxRates();
}
function isEquityCompAccount(account) {
  return String(account?.type || "").toUpperCase() === "ESOP";
}
function portfolioAccounts() {
  return (state.localAccounts || []).filter((account) => !isEquityCompAccount(account));
}
function isEquityCompHolding(item) {
  const holding = item?.holding || {};
  const assetClass = String(holding.asset_class || holding.asset_sub_class || "").toUpperCase();
  const account = state.localAccounts.find((candidate) => String(candidate.id || "") === String(holding.account_id || ""));
  return isEquityCompAccount(account)
    || String(holding.account_type || "").toUpperCase() === "ESOP"
    || ["RSU", "STOCK_OPTION", "EMPLOYEE_STOCK_OPTION"].includes(assetClass);
}
function portfolioItems(items) {
  return (items || []).filter((item) => !isEquityCompHolding(item));
}
function accountCashBalance(account, asOfDate = null) {
  if (!account) return 0;
  const transactions = state.localTransactions.filter((tx) => String(tx.account_db_id || "") === String(account.id || "")
    && (!asOfDate || String(tx.trade_date || "") <= asOfDate));
  return Number(account.initial_cash || 0) + sum(transactions.map(transactionCashImpact));
}
function accountCashValue(account) {
  if (!account) return 0;
  return Math.max(0, normalizedAmount(accountCashBalance(account), account.currency));
}
function accountRiskCashValue(account) {
  return account ? normalizedAmount(accountCashBalance(account), account.currency) : 0;
}
function accountRecordForHolding(holding) {
  return state.localAccounts.find((account) => account.id === holding.account_id)
    || state.localAccounts.find((account) => cleanSourceLabel(accountLabel(account)) === cleanSourceLabel(holding.account));
}
function assetRiskFactor(item) {
  const h = item.holding || {};
  const asset = String(h.asset_class || h.asset_sub_class || "").toUpperCase();
  const instrument = String(h.asset_sub_class || "").toUpperCase();
  const symbol = String(h.symbol || "").toUpperCase();
  if (["OPTION", "FUTURE", "STOCK_OPTION", "EMPLOYEE_STOCK_OPTION"].includes(asset) || ["OPTION", "FUTURE", "STOCK_OPTION", "EMPLOYEE_STOCK_OPTION"].includes(instrument)) return 1;
  if (symbol.includes("3X") || symbol.includes("2X") || symbol.includes("LEVERAGED")) return 1;
  const focus = item.exposure_profile?.asset_focus;
  const focusFactors = {
    money_market: 0.12, government_bond: 0.2, investment_grade_bond: 0.35,
    high_yield_bond: 0.6, broad_equity: 0.65, single_country_equity: 0.75,
    sector_equity: 0.8, multi_asset: 0.5, real_estate: 0.7,
    commodity: 0.85, derivative: 1, other: 0.7,
  };
  if (focus && Object.hasOwn(focusFactors, focus)) return focusFactors[focus];
  if (asset === "BOND") return 0.35;
  if (asset === "ETF" || asset === "MUTUALFUND") return 0.45;
  if (asset === "EQUITY" || asset === "RSU") return 0.65;
  if (["CRYPTO", "COMMODITY", "OTHER"].includes(asset)) return 0.85;
  return 0.7;
}
function clamp(value, min, max) {
  return Math.min(Math.max(Number(value || 0), min), max);
}
function derivativeHolding(item) {
  const h = item.holding || {};
  const asset = String(h.asset_class || "").toUpperCase();
  const instrument = String(h.asset_sub_class || "").toUpperCase();
  const symbol = String(h.symbol || "").toUpperCase();
  return ["OPTION", "FUTURE", "STOCK_OPTION", "EMPLOYEE_STOCK_OPTION"].includes(asset) || ["OPTION", "FUTURE", "STOCK_OPTION", "EMPLOYEE_STOCK_OPTION"].includes(instrument) || symbol.includes("3X") || symbol.includes("2X") || symbol.includes("LEVERAGED");
}
function diversifiedFund(item) {
  const h = item.holding || {};
  const asset = String(h.asset_class || "").toUpperCase();
  const symbol = String(h.symbol || "").toUpperCase();
  const industry = String(item.industry || h.industry || h.sector || "").toLowerCase();
  if (!["ETF", "MUTUALFUND"].includes(asset)) return false;
  if (derivativeHolding(item)) return false;
  const focus = item.exposure_profile?.asset_focus;
  if (focus) {
    const sector = String(item.exposure_profile.sector_exposure || "").trim().toLowerCase();
    return (!sector || sector === "broad market")
      && ["broad_equity", "multi_asset", "money_market", "government_bond", "investment_grade_bond"].includes(focus);
  }
  if (industry.includes("sector") || industry.includes("industry")) return false;
  return !/(ARKK|SOXX|XLK|XLE|XLF|XLV|XLI|XLY|XLP|XLU|XLB|XLC|XBI|KWEB|TAN|ICLN|SMH)/.test(symbol);
}
function industryLabel(item) {
  const h = item.holding || {};
  const asset = String(h.asset_class || "").toUpperCase();
  const instrument = String(h.asset_sub_class || "").toUpperCase();
  if (asset === "BOND" || instrument === "BOND") return "Bonds";
  if (item.industry_source === "manual") return String(item.industry || "").trim();
  if (item.exposure_profile?.sector_exposure) return item.exposure_profile.sector_exposure;
  if (item.exposure_profile?.asset_focus === "money_market") return "Money market";
  if (diversifiedFund(item)) return "Diversified fund";
  return String(item.industry || h.industry || h.sector || "").trim();
}
function issuerLabel(item) {
  const h = item.holding || {};
  return String(h.symbol || h.name || "Unknown").trim().toUpperCase();
}
function countryLabel(item) {
  const h = item.holding || {};
  const fund = ["ETF", "MUTUALFUND"].includes(String(h.asset_class || "").toUpperCase());
  if (fund) return item.exposure_profile?.asset_focus === "single_country_equity"
    ? String(item.exposure_profile.geography || "").trim() : "";
  if (item.exposure_profile?.geography) return item.exposure_profile.geography;
  return String(h.country || h.location || "").trim();
}
function economicCurrencyExposure(item) {
  const h = item.holding || {};
  const profile = item.exposure_profile;
  const fund = ["ETF", "MUTUALFUND"].includes(String(h.asset_class || "").toUpperCase());
  if (!profile && !fund) return { allocations: [{ currency: h.currency || state.baseCurrency, percent: 100 }], unknownPercent: 0 };
  const enteredAllocations = profile?.currency_exposures || [];
  // A named FX exposure is a complete allocation when the user has not supplied
  // a detailed split. This avoids making users enter the same currency twice.
  const allocations = profile?.fx_basis === "unknown" ? []
    : (enteredAllocations.length
      ? enteredAllocations
      : (profile?.fx_reference_currency
        ? [{ currency: profile.fx_reference_currency, percent: 100 }]
        : []));
  return { allocations, unknownPercent: Math.max(0, 100 - sum(allocations.map((row) => Number(row.percent || 0)))) };
}
function volatilityProxy(item) {
  const h = item.holding || {};
  const range = item.price_ranges?.["1y"] || {};
  const high = Number(range.high || 0);
  const low = Number(range.min || 0);
  const current = Number(range.current || h.market_value / Math.max(Math.abs(Number(h.quantity || 0)), 1) || 0);
  if (high > 0 && low > 0 && current > 0 && high >= low) {
    return clamp(((high - low) / current) * 100, 0, 120);
  }
  if (derivativeHolding(item)) return 90;
  const asset = String(h.asset_class || "").toUpperCase();
  if (asset === "BOND") return 14;
  if (item.exposure_profile?.asset_focus === "money_market") return 12;
  if (asset === "ETF" || asset === "MUTUALFUND") return diversifiedFund(item) ? 24 : 36;
  if (asset === "EQUITY") return 48;
  return 55;
}
function personHorizonYears(person) {
  const age = Number(person?.age || ageFromBirthDate(person?.birth_date));
  if (!age) return null;
  return Math.max(0, Number(person?.retire_age || 67) - age);
}
function accountHorizonYears(account) {
  const horizons = (account?.persons || []).map(personHorizonYears).filter((value) => value !== null);
  if (horizons.length) return Math.min(...horizons);
  if (account?.type === "Long-Term Savings") return 15;
  return null;
}
function riskScoreForItems(items, options = {}) {
  const rows = items || [];
  const valueOfHolding = options.normalizeField || normalizedField;
  const baseCurrency = options.baseCurrency || state.baseCurrency;
  const label = options.label || "Portfolio risk";
  const signedCash = Number(options.cash || 0);
  const cashDebt = Math.max(0, -signedCash, Number(options.cashDebt || 0));
  const cash = Math.max(0, signedCash + cashDebt);
  const horizonYears = options.horizonYears ?? null;
  const values = rows.map((item) => Math.abs(valueOfHolding(item, "market_value"))).filter((value) => value > 0);
  const holdingsValue = sum(values);
  const netEquity = sum(rows.map((item) => valueOfHolding(item, "market_value"))) + signedCash;
  const totalValue = holdingsValue + cash;
  if (totalValue <= 0) {
    return { model: "portfolio-risk-v2", label, score: cashDebt > 0 ? 100 : 0,
      components: cashDebt > 0 ? { borrowing: 100 } : {}, drivers: [cashDebt > 0 ? "Non-positive net equity" : "No account value"],
      cash_debt: cashDebt, net_equity: netEquity, unlevered_score: 0, position_risks: new Map(), cash_pct: 0 };
  }

  const topPositionPct = values.length ? Math.max(...values) / totalValue * 100 : 0;
  const hhi = rows.reduce((total, item) => {
    const pct = Math.abs(valueOfHolding(item, "market_value")) / totalValue * 100;
    return total + pct * pct;
  }, 0);
  const concentration = Math.min(topPositionPct / 40, 1) * 10 + Math.min(hhi / 2500, 1) * 6;

  const weightedAsset = rows.reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")) * assetRiskFactor(item), cash * 0.05);
  const assetMix = totalValue ? weightedAsset / totalValue * 14 : 0;

  const currencyTotals = rows.reduce((totals, item) => {
    const value = Math.abs(valueOfHolding(item, "market_value"));
    economicCurrencyExposure(item).allocations.forEach(({ currency, percent }) => {
      totals[currency] = (totals[currency] || 0) + value * Number(percent || 0) / 100;
    });
    return totals;
  }, {});
  const unknownCurrencyValue = rows.reduce((total, item) => total
    + Math.abs(valueOfHolding(item, "market_value")) * economicCurrencyExposure(item).unknownPercent / 100, 0);
  if (cash) {
    const cashCurrency = options.cashCurrency || baseCurrency;
    currencyTotals[cashCurrency] = (currencyTotals[cashCurrency] || 0) + cash;
  }
  const foreignValues = Object.entries(currencyTotals).filter(([currency]) => currency !== baseCurrency).map(([, value]) => value);
  const nonBaseCurrencyPct = sum(foreignValues) / totalValue * 100;
  const largestForeignCurrencyPct = (foreignValues.length ? Math.max(...foreignValues) : 0) / totalValue * 100;
  const currency = Math.min(nonBaseCurrencyPct / 80, 1) * 7 + Math.min(largestForeignCurrencyPct / 60, 1) * 3;

  const industryRows = rows.filter((item) => Math.abs(valueOfHolding(item, "market_value")) > 0
    && ["EQUITY", "RSU", "ETF", "MUTUALFUND"].includes(String(item.holding.asset_class || "").toUpperCase())
    && !["money_market", "government_bond", "investment_grade_bond", "high_yield_bond"].includes(item.exposure_profile?.asset_focus));
  const industryTotals = industryRows.reduce((totals, item) => {
    const industry = industryLabel(item);
    if (!industry) return totals;
    totals[industry] = (totals[industry] || 0) + Math.abs(valueOfHolding(item, "market_value"));
    return totals;
  }, {});
  const industryHhi = Object.values(industryTotals).reduce((total, value) => {
    const pct = Number(value || 0) / Math.max(holdingsValue, 1) * 100;
    return total + pct * pct;
  }, 0);
  const missingIndustryPct = holdingsValue ? industryRows
    .filter((item) => !industryLabel(item))
    .reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")), 0) / holdingsValue * 100 : 0;
  const industry = Math.min(industryHhi / 3000, 1) * 7 + missingIndustryPct / 100 * 3;

  const cashPct = cash / totalValue * 100;
  const cashScore = cashPct >= 5 && cashPct <= 20 ? 0 : cashPct < 5 ? (5 - cashPct) / 5 * 7 : Math.min((cashPct - 20) / 50, 1) * 4;

  const derivativesValue = rows
    .filter(derivativeHolding)
    .reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")), 0);
  const derivativePct = derivativesValue / totalValue * 100;
  const hasShort = rows.some((item) => Number(item.holding.quantity || 0) < 0);
  const derivatives = Math.min(derivativePct / 25, 1) * 8 + (hasShort ? 2 : 0);

  const weightedVolatility = rows.reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")) * volatilityProxy(item), 0);
  const avgVolatilityPct = holdingsValue ? weightedVolatility / holdingsValue : 0;
  const volatility = Math.min(avgVolatilityPct / 60, 1) * 10;

  const riskyAssetPct = totalValue ? rows
    .filter((item) => assetRiskFactor(item) >= 0.65 || derivativeHolding(item))
    .reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")), 0) / totalValue * 100 : 0;
  let horizon = 0;
  if (horizonYears !== null && horizonYears !== undefined) {
    const shortHorizonPressure = horizonYears < 3 ? 1 : horizonYears < 7 ? (7 - horizonYears) / 4 : 0;
    const longHorizonUnderRisk = horizonYears > 15 && riskyAssetPct < 35 ? Math.min((35 - riskyAssetPct) / 35, 1) * 0.35 : 0;
    horizon = Math.min((shortHorizonPressure * (riskyAssetPct / 100) + longHorizonUnderRisk) * 10, 10);
  }

  const issuerRiskTotals = rows.reduce((totals, item) => {
    const issuer = issuerLabel(item);
    const fundLookThroughWeight = diversifiedFund(item) ? 0.35 : 1;
    totals[issuer] = (totals[issuer] || 0) + Math.abs(valueOfHolding(item, "market_value")) * fundLookThroughWeight;
    return totals;
  }, {});
  const symbolTotals = rows.reduce((totals, item) => {
    const symbol = issuerLabel(item);
    totals[symbol] = (totals[symbol] || 0) + Math.abs(valueOfHolding(item, "market_value"));
    return totals;
  }, {});
  const countryTotals = rows.reduce((totals, item) => {
    const country = countryLabel(item);
    if (!country) return totals;
    totals[country] = (totals[country] || 0) + Math.abs(valueOfHolding(item, "market_value"));
    return totals;
  }, {});
  const largestIssuerRiskPct = holdingsValue ? Math.max(0, ...Object.values(issuerRiskTotals)) / holdingsValue * 100 : 0;
  const largestSymbolPct = holdingsValue ? Math.max(0, ...Object.values(symbolTotals)) / holdingsValue * 100 : 0;
  const largestCountryPct = holdingsValue ? Math.max(0, ...Object.values(countryTotals)) / holdingsValue * 100 : 0;
  const issuerCountry = Math.min(largestIssuerRiskPct / 35, 1) * 4 + Math.max(0, Math.min((largestCountryPct - 55) / 35, 1)) * 4;

  const missingPricePct = holdingsValue ? rows.filter((item) => (item.missing || []).includes("price history")).reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")), 0) / holdingsValue * 100 : 0;
  const missingClassPct = holdingsValue ? rows.filter((item) => !item.holding.asset_class || !item.holding.currency).reduce((total, item) => total + Math.abs(valueOfHolding(item, "market_value")), 0) / holdingsValue * 100 : 0;
  const dataQuality = Math.min(missingPricePct / 100 * 2 + missingIndustryPct / 100 * 1.5
    + missingClassPct / 100 * 1.5 + unknownCurrencyValue / totalValue * 1.5, 5);

  const components = {
    concentration,
    asset_mix: assetMix,
    currency,
    industry,
    cash: cashScore,
    derivatives,
    volatility,
    horizon,
    issuer_country: issuerCountry,
    data_quality: dataQuality,
  };
  const unleveredScore = sum(Object.values(components));
  const nonPositiveEquity = netEquity <= 0 && (holdingsValue > 0 || cashDebt > 0);
  const borrowing = nonPositiveEquity ? Math.max(0, 100 - unleveredScore)
    : cashDebt > 0 ? Math.max(0, Math.min(100 - unleveredScore, unleveredScore * cashDebt / netEquity)) : 0;
  components.borrowing = borrowing;
  const score = Math.min(Math.max(Math.round(unleveredScore + borrowing), 0), 100);
  const drivers = [
    topPositionPct > 25 ? `Top holding ${fmt(topPositionPct, 1)}%` : "",
    nonBaseCurrencyPct > 40 ? `Foreign currency ${fmt(nonBaseCurrencyPct, 1)}%` : "",
    unknownCurrencyValue / totalValue > 0.1 ? `Unknown FX exposure ${fmt(unknownCurrencyValue / totalValue * 100, 1)}%` : "",
    derivativePct > 0 ? `Options/futures/leverage ${fmt(derivativePct, 1)}%` : "",
    avgVolatilityPct > 35 ? `1Y volatility proxy ${fmt(avgVolatilityPct, 1)}%` : "",
    horizonYears !== null && horizonYears !== undefined ? `Horizon ${fmt(horizonYears, 1)} years` : "",
    largestSymbolPct > 25 ? `Symbol concentration ${fmt(largestSymbolPct, 1)}%` : "",
    largestCountryPct > 70 ? `Country concentration ${fmt(largestCountryPct, 1)}%` : "",
    cashPct < 5 ? `Low cash ${fmt(cashPct, 1)}%` : cashPct > 20 ? `High cash ${fmt(cashPct, 1)}%` : "",
    missingIndustryPct > 20 ? `Missing industry ${fmt(missingIndustryPct, 1)}%` : "",
  ].filter(Boolean);
  const positionRisks = new Map(rows.map((item) => {
    const valuePct = Math.abs(valueOfHolding(item, "market_value")) / totalValue * 100;
    const itemVolatility = volatilityProxy(item);
    const itemScore = Math.min(Math.round(valuePct * 0.65 + assetRiskFactor(item) * 20 + itemVolatility / 120 * 15 + (derivativeHolding(item) ? 15 : 0) + ((item.missing || []).length ? 6 : 0)), 100);
    return [item, {
      label: `${item.holding.symbol} holding risk`,
      score: nonPositiveEquity ? 100 : Math.min(100, Math.round(itemScore * (1 + (cashDebt > 0 ? cashDebt / netEquity : 0)))),
      cash_debt: cashDebt,
      net_equity: netEquity,
      components,
      show_component_breakdown: false,
      drivers: [
        `Holding weight ${fmt(valuePct, 1)}%`,
        `Asset factor ${fmt(assetRiskFactor(item), 2)}`,
        `1Y volatility proxy ${fmt(itemVolatility, 1)}%`,
        diversifiedFund(item) ? "ETF/fund treated as diversified proxy" : "",
        derivativeHolding(item) ? "Option/future/leveraged instrument" : "",
        ...(item.missing || []).slice(0, 2).map((label) => `Missing ${label}`),
      ].filter(Boolean),
    }];
  }));
  return { model: "portfolio-risk-v2", label, score, components, drivers, position_risks: positionRisks, cash_pct: cashPct,
    quality_details: typeof riskMissingDataDetails === "function" ? riskMissingDataDetails(rows, { normalizeField: valueOfHolding, holdingsValue, totalValue, industryRows }) : [],
    cash_debt: cashDebt, net_equity: netEquity, unlevered_score: unleveredScore };
}
function portfolioRiskSnapshot(items) {
  const accountsById = Object.fromEntries(state.localAccounts.map((account) => [account.id, account]));
  const itemsByAccount = items.reduce((groups, item) => {
    const key = item.holding.account_id || cleanSourceLabel(item.holding.account) || "Unassigned";
    groups[key] = groups[key] || [];
    groups[key].push(item);
    return groups;
  }, {});
  portfolioAccounts().forEach((account) => {
    if (Math.abs(accountRiskCashValue(account)) > 0 && !itemsByAccount[account.id]) itemsByAccount[account.id] = [];
  });
  const accountRisks = Object.entries(itemsByAccount).map(([key, rows]) => {
    const account = accountsById[key] || (rows[0] ? accountRecordForHolding(rows[0].holding) : null);
    const cash = accountRiskCashValue(account);
    const value = sum(rows.map((item) => Math.abs(normalizedField(item, "market_value")))) + Math.max(0, cash);
    const horizonYears = accountHorizonYears(account);
    const label = cleanSourceLabel(rows[0]?.holding.account) || account?.account_id || "Unassigned";
    return {
      key,
      account: label,
      value,
      horizonYears,
      risk: riskScoreForItems(rows, { label: `${label || "Account"} risk`, cash, cashCurrency: account?.currency, horizonYears }),
      allocation: riskAllocationForItems(rows, { cash, cashCurrency: account?.currency }),
    };
  });
  const combinedCash = sum(portfolioAccounts().map(accountRiskCashValue));
  const combinedDebt = sum(portfolioAccounts().map((account) => Math.max(0, -accountRiskCashValue(account))));
  const portfolioHorizons = portfolioAccounts().map(accountHorizonYears).filter((value) => value !== null);
  const portfolioHorizonYears = portfolioHorizons.length ? Math.min(...portfolioHorizons) : null;
  const combinedRisk = riskScoreForItems(items, { label: "Total portfolio risk", cash: combinedCash, cashDebt: combinedDebt, horizonYears: portfolioHorizonYears });
  const holdingsValue = sum(items.map((item) => Math.abs(normalizedField(item, "market_value"))));
  const nav = sum(accountRisks.map((entry) => entry.value)) || 1;
  const weightedAccountScore = accountRisks.reduce((total, entry) => {
    return total + entry.risk.score * (entry.value / nav);
  }, 0);
  const score = combinedRisk.net_equity <= 0 && (holdingsValue > 0 || combinedDebt > 0) ? 100
    : Math.min(Math.max(Math.round(0.75 * combinedRisk.score + 0.25 * weightedAccountScore), 0), 100);
  const totalRisk = { ...combinedRisk, score, label: "Total portfolio risk" };
  return { total: totalRisk, accounts: accountRisks };
}
function riskAllocationForItems(items, options = {}) {
  const cash = Math.max(0, Number(options.cash || 0));
  const cashCurrency = String(options.cashCurrency || state.baseCurrency || "").toUpperCase();
  const baseCurrency = String(state.baseCurrency || "").toUpperCase();
  const bands = [
    { key: "no-risk", label: "No risk", value: cashCurrency === baseCurrency ? cash : 0 },
    { key: "low", label: "Low risk", value: cashCurrency === baseCurrency ? 0 : cash },
    { key: "medium", label: "Medium risk", value: 0 },
    { key: "high", label: "High risk", value: 0 },
  ];
  const byKey = Object.fromEntries(bands.map((band) => [band.key, band]));
  (items || []).forEach((item) => {
    byKey[riskAllocationBand(item)].value += Math.abs(normalizedField(item, "market_value"));
  });
  const total = sum(bands.map((band) => band.value));
  let allocatedPercent = 0;
  return {
    total,
    bands: bands.map((band, index) => {
      const percent = total
        ? (index === bands.length - 1 ? Math.max(0, 100 - allocatedPercent) : Math.round(band.value / total * 1000) / 10)
        : 0;
      allocatedPercent += percent;
      return { ...band, percent };
    }),
  };
}
function riskAllocationBand(item) {
  const factor = assetRiskFactor(item);
  const foreignCurrencyExposure = economicCurrencyExposure(item).allocations
    .some(({ currency, percent }) => String(currency || "").toUpperCase() !== String(state.baseCurrency || "").toUpperCase() && Number(percent || 0) > 0);
  if (factor <= 0.12) return foreignCurrencyExposure ? "low" : "no-risk";
  if (factor <= 0.35) return "low";
  if (factor <= 0.65) return "medium";
  return "high";
}
function cleanSourceLabel(value) {
  const legacyName = String.fromCharCode(71, 104, 111, 115, 116, 102, 111, 108, 105, 111);
  return String(value || "").replace(new RegExp(legacyName, "gi"), "").replace(/import-/gi, "").replace(/\s+/g, " ").trim().replace(/^[\s-]+|[\s-]+$/g, "");
}
function transactionCashImpact(tx) {
  const value = Number(tx.quantity || 0) * Number(tx.price || 0);
  if (tx.action === "BUY" || tx.action === "CASH_OUT") return -value;
  if (tx.action === "SELL" || tx.action === "SHORT" || tx.action === "DIVIDEND" || tx.action === "INTEREST" || tx.action === "CASH_IN") return value;
  if (tx.action === "FEE") return -value;
  return 0;
}
function ageFromBirthDate(value) {
  if (!value) return "";
  const birth = new Date(`${value}T00:00:00`);
  if (Number.isNaN(birth.getTime())) return "";
  const today = new Date();
  const diffDays = (Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) - Date.UTC(birth.getFullYear(), birth.getMonth(), birth.getDate())) / 86400000;
  return diffDays >= 0 ? Math.round((diffDays / 365.2425) * 100) / 100 : "";
}
function summarize(context) {
  state.baseCurrency=context.base_currency;state.localAccounts=context.accounts;
  state.localTransactions=context.transactions||[];setCoreFxRates(context.fx);
  const items=portfolioItems(context.items);
  const snapshot=portfolioRiskSnapshot(items);
  const clean=r=>{const {position_risks,...other}=r;return other;};
  const accounts=snapshot.accounts.map(a=>({...a,risk:clean(a.risk)}));
  const nav=sum(accounts.map(a=>a.value))||1;
  const w=sum(accounts.map(a=>a.risk.score*a.value/nav));
  const c=snapshot.total;
  const raw=c.net_equity<=0&&(items.length||c.cash_debt>0)?100:
    .75*Math.round(c.unlevered_score+(c.components.borrowing||0))+.25*w;
  return {score:c.score,raw_score:raw,combined_score:Math.round(c.unlevered_score+(c.components.borrowing||0)),
    weighted_accounts:w,total:clean(c),accounts,positions:items.map(i=>({
      account_id:i.holding.account_id,symbol:i.holding.symbol,value:normalizedField(i,'market_value'),
      asset_factor:assetRiskFactor(i),volatility_proxy:volatilityProxy(i),derivative:derivativeHolding(i),
      diversified:diversifiedFund(i),industry:industryLabel(i),country:countryLabel(i),
      currency_exposure:economicCurrencyExposure(i)}))};
}
function stateContext(s) {
  const rate=c=>c===s.base_currency?1:s.fx_rates[c];
  return {base_currency:s.base_currency,fx:{quotes:Object.entries(s.fx_rates).filter(([c])=>c!==s.base_currency).map(([c,r])=>({pair:c+'/'+s.base_currency,quote:{rate:r}}))},
    accounts:s.accounts.map(a=>({id:a.id,type:a.type,currency:a.currency,initial_cash:a.cash/rate(a.currency),
      account_id:a.label,management_company:a.label,persons:a.horizon_years==null?[]:[{age:40,retire_age:40+a.horizon_years}]})),
    items:s.positions.filter(p=>Math.abs(p.value)>1e-9).map(p=>{
      let item=JSON.parse(JSON.stringify(p.item||{}));
      item.holding={...(item.holding||{}),symbol:p.symbol,account_id:p.account_id,asset_class:p.asset_class,
        currency:p.currency,market_value:p.value/rate(p.currency),quantity:p.quantity??1,country:p.country};
      item.industry=p.industry;item.missing=p.missing||[];
      item.exposure_profile={...(item.exposure_profile||{}),asset_focus:p.asset_focus||undefined,
        fx_basis:'reported',currency_exposures:Object.entries(p.currency_exposures).map(([currency,f])=>({currency,percent:f*100})),
        fx_reference_currency:undefined};
      // Keep the captured range ratio fixed for forward composition experiments.
      // Observed market shocks change values, not an invented return history.
      return item;
    })};
}
const input=JSON.parse(fs.readFileSync(0,'utf8'));
if(input.states) process.stdout.write(JSON.stringify(input.states.map(s=>{const r=summarize(stateContext(s));if(input.slim){delete r.positions;for(const a of r.accounts)delete a.allocation;}return r;})));
else process.stdout.write(JSON.stringify(summarize(input)));
