"""100 deterministic variants per frozen family; no outcome-based fitting."""
from collections import Counter, defaultdict
from copy import deepcopy
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess

from candidate_formulas import evaluate, evaluate_accounts, static_score, STATIC_RUBRIC, NAMES

HERE=Path(__file__).resolve().parent
BASE=json.loads((HERE/'snapshot.json').read_text())
MODELS=['F0','F1','F2','F3','F4']
NAMES={'F0':'Current portfolio-risk-v2',**NAMES}
def equity(s):return math.fsum(p['value'] for p in s['positions'])+math.fsum(a['cash'] for a in s['accounts'])
E=equity(BASE)
AUDIT=json.loads((HERE/'value_audit.json').read_text())
FUND_TOTAL=AUDIT['separate_funds_total']
def investment(a):return a['type']=='Investment'
usd_accounts=[a for a in BASE['accounts'] if investment(a) and a['currency']=='USD']
usd_ids={a['id'] for a in usd_accounts}
by_issuer=defaultdict(float)
for p in BASE['positions']:
    if p['asset_class']=='EQUITY':by_issuer[p['issuer']]+=p['value']
largest=max(by_issuer,key=by_issuer.get)
template=next(p for p in BASE['positions'] if p['symbol']==largest)
receiver=max(usd_accounts,key=lambda a:a['securities_value'])['id']
FAMILIES={
 'equity_to_cash':{'label':'Sell USD equities to same-account USD cash','parameter':'sale_fraction','from':.01,'to':1,'units':'fraction','expectation':'nonincreasing','equity_invariant':True},
 'money_market_to_cash':{'label':'Redeem ILS money-market fund to ILS cash','parameter':'sale_fraction','from':.01,'to':1,'units':'fraction','expectation':'nonincreasing','equity_invariant':True},
 'debt_funded_buy':{'label':'Buy largest equity using account cash then borrowing','parameter':'purchase_share_of_initial_equity','from':.005,'to':.5,'units':'fraction','expectation':'nondecreasing','equity_invariant':True},
 'issuer_concentration':{'label':'Consolidate stock book into largest stock issuer','parameter':'consolidated_share','from':.01,'to':1,'units':'fraction','expectation':None,'equity_invariant':True},
 'equity_drawdown':{'label':'All equity marks decline; FX fixed','parameter':'equity_price_decline','from':.006,'to':.6,'units':'fraction','expectation':None,'equity_invariant':False},
 'usd_depreciation':{'label':'USD depreciates against ILS; local prices fixed','parameter':'usd_depreciation','from':.003,'to':.3,'units':'fraction','expectation':None,'equity_invariant':False},
 'bond_mark_decline':{'label':'Bond prices decline; no assumed rate-to-price mapping','parameter':'bond_price_decline','from':.002,'to':.2,'units':'fraction','expectation':None,'equity_invariant':False},
 'joint_market_fx':{'label':'Joint equity, bond, and USD decline','parameter':'equity_decline; USD=half; bonds=0.3 times','from':.005,'to':.5,'units':'fraction','expectation':None,'equity_invariant':False},
 'largest_issuer_failure':{'label':'Largest stock issuer declines toward total loss','parameter':'issuer_price_decline','from':.01,'to':1,'units':'fraction','expectation':None,'equity_invariant':False},
 'cash_injection':{'label':'Add external ILS cash, holdings fixed','parameter':'cash_added_share_of_initial_equity','from':.01,'to':1,'units':'fraction','expectation':'nonincreasing','equity_invariant':False},
 'scale_invariance':{'label':'Scale positions and cash without changing weights','parameter':'portfolio_scale','from':.1,'to':10,'units':'multiple','expectation':'equal_baseline','equity_invariant':False},
 'lot_split_invariance':{'label':'Represent every position as economically identical lots','parameter':'lots_per_position','from':2,'to':101,'units':'count','expectation':'equal_baseline','equity_invariant':True},
 'account_partition_invariance':{'label':'Repartition positions among identical debt-free USD subaccounts','parameter':'representation_variant','from':1,'to':100,'units':'index','expectation':'equal_baseline','equity_invariant':True},
 'unknown_fund_allocation':{'label':'Conditional whole-wealth allocation of otherwise unmodeled savings funds','parameter':'assumed_unhedged_USD_equity_share; rest ILS money market','from':0,'to':1,'units':'fraction','expectation':None,'equity_invariant':False,'scope':'all_accounts_conditional','reference_equity':E+FUND_TOTAL},
}
protocol={'version':'risk-review-20261113-v1','frozen_at':datetime.now(timezone.utc).isoformat(),
 'variants_per_family':100,'family_count':len(FAMILIES),'scenario_count':100*len(FAMILIES),
 'families':FAMILIES,'models':NAMES,'information_cutoff':'Saved inputs captured 13/11/2026, dated quotes retained',
 'ranking':'Quality, not measured forecast accuracy; static50 + behavior50; no fit to these simulations',
 'behavior_criteria':{'scale_invariance':['scale_invariance'],'lot_split_invariance':['lot_split_invariance'],
   'cash_sale_monotonicity':['equity_to_cash','money_market_to_cash'],'leverage_monotonicity':['debt_funded_buy'],
   'account_partition_invariance':['account_partition_invariance']},
 'behavior_points_each':10,'comparison_tolerance':1e-7,'monotonicity':'Each variant compared with preceding one, starting at unchanged baseline',
 'invariance':'Compare raw score with unchanged baseline; exact current raw is pre-final-round blend of rounded combined and account scores',
 'fees_tax_slippage_financing':'Excluded; composition changes occur at frozen saved marks, in same account currency; no orders or ledger writes',
 'selection':'Deterministic sensitivity sweeps, no random seed; repeated/similar cases are not independent outcomes',
 'stress_recalculation':'Scenario states keep captured historical range ratio fixed; simulated marks do not invent a new trailing price history',
 'static_rubric':STATIC_RUBRIC,'snapshot_sha256':hashlib.sha256((HERE/'snapshot.json').read_bytes()).hexdigest(),
 'method_sha256':hashlib.sha256((HERE/'candidate_formulas.py').read_bytes()).hexdigest()}
(HERE/'protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2))

def create(family,index):
    s=deepcopy(BASE);t=(index+1)/100
    accounts={a['id']:a for a in s['accounts']}
    parameter=t
    if family in {'equity_to_cash','money_market_to_cash'}:
        for p in s['positions']:
            selected=p['asset_class']=='EQUITY' if family=='equity_to_cash' else p['asset_focus']=='money_market'
            if selected:
                proceeds=p['value']*t;p['value']-=proceeds;p['quantity']*=1-t
                accounts[p['account_id']]['cash']+=proceeds
    elif family=='debt_funded_buy':
        parameter=.5*t;p=deepcopy(template);p['account_id']=receiver;p['value']=parameter*E
        p['quantity']=template['quantity']*p['value']/template['value']
        s['positions'].append(p);accounts[receiver]['cash']-=p['value']
    elif family=='issuer_concentration':
        proceeds=defaultdict(float)
        for p in s['positions']:
            if p['asset_class']=='EQUITY':
                proceeds[p['account_id']]+=p['value']*t;p['value']*=1-t;p['quantity']*=1-t
        for aid,amount in proceeds.items():
            p=deepcopy(template);p['account_id']=aid;p['value']=amount;p['quantity']=template['quantity']*amount/template['value'];s['positions'].append(p)
    elif family in {'equity_drawdown','bond_mark_decline','largest_issuer_failure','joint_market_fx'}:
        parameter={'equity_drawdown':.6,'bond_mark_decline':.2,'largest_issuer_failure':1,'joint_market_fx':.5}[family]*t
        for p in s['positions']:
            decline=parameter if (family=='equity_drawdown' and p['asset_class']=='EQUITY') or (family=='bond_mark_decline' and p['asset_class']=='BOND') or (family=='largest_issuer_failure' and p['issuer']==largest) else 0
            if family=='joint_market_fx':decline=parameter if p['asset_class']=='EQUITY' else .3*parameter if p['asset_class']=='BOND' else 0
            p['value']*=1-decline
        if family=='joint_market_fx':
            fx=.5*parameter
            for p in s['positions']:p['value']*=1-fx*p['currency_exposures'].get('USD',0)
            for a in s['accounts']:
                if a['currency']=='USD':a['cash']*=1-fx
            s['fx_rates']['USD']*=1-fx
    elif family=='usd_depreciation':
        parameter=.3*t
        for p in s['positions']:p['value']*=1-parameter*p['currency_exposures'].get('USD',0)
        for a in s['accounts']:
            if a['currency']=='USD':a['cash']*=1-parameter
        s['fx_rates']['USD']*=1-parameter
    elif family=='cash_injection':
        accounts[next(p['account_id'] for p in s['positions'] if p['asset_focus']=='money_market')]['cash']+=E*t
    elif family=='scale_invariance':
        parameter=.1+9.9*index/99
        for p in s['positions']:p['value']*=parameter;p['quantity']*=parameter
        for a in s['accounts']:a['cash']*=parameter
    elif family=='lot_split_invariance':
        parameter=index+2;rows=[]
        for p in s['positions']:
            for _ in range(parameter):
                clone=deepcopy(p);clone['value']/=parameter;clone['quantity']/=parameter;rows.append(clone)
        s['positions']=rows
    elif family=='account_partition_invariance':
        parameter=index+1;new_accounts=[a for a in s['accounts'] if a['id'] not in usd_ids]
        # Only representations change. Each original account's horizon/currency,
        # positions and positive cash remain the same in aggregate. No new debt.
        for source in usd_accounts:
            ps=[p for p in s['positions'] if p['account_id']==source['id']]
            n=2+index%max(2,len(ps))
            weights=[1+((j+1)*(index+3)%19) for j in range(n)];den=sum(weights)
            for j in range(n):
                a=deepcopy(source);a['id']=source['id']+f'::part{j}';a['cash']=source['cash']*weights[j]/den;a['label']=source['label']+f' part{j+1}';new_accounts.append(a)
            for j,p in enumerate(ps):p['account_id']=source['id']+f'::part{(j*7+index)%n}'
        s['accounts']=new_accounts
    elif family=='unknown_fund_allocation':
        parameter=index/99
        for f in AUDIT['separate_funds']:
            for focus,weight,currency in [('broad_equity',parameter,'USD'),('money_market',1-parameter,'ILS')]:
                if weight==0:continue
                symbol='ASSUMED-'+f['id']+'-'+focus
                value=f['amount']*weight
                s['positions'].append({'account_id':f['account_id'],'symbol':symbol,'issuer':symbol,
                  'value':value,'asset_class':'MUTUALFUND','asset_focus':focus,'industry':'Diversified fund' if focus=='broad_equity' else 'Money market',
                  'sector':'','country':'','currency':'ILS','quantity':value,'asset_factor':.65 if focus=='broad_equity' else .12,
                  'currency_exposures':{currency:1},'unknown_currency':0,'volatility_proxy':24 if focus=='broad_equity' else 12,
                  'derivative':False,'diversified':True,'missing':[],
                  'item':{'price_ranges':{},'holding':{'stock_market':'HYPOTHETICAL'},'exposure_profile':{'asset_focus':focus}}})
        assert math.isclose(equity(s),E+FUND_TOTAL,abs_tol=1e-5)
    else:raise ValueError(family)
    s['positions']=[p for p in s['positions'] if abs(p['value'])>1e-9]
    if FAMILIES[family]['equity_invariant']:assert math.isclose(equity(s),E,abs_tol=1e-5,rel_tol=1e-12),(family,index,equity(s),E)
    return s,parameter

def f0_batch(states):
    return json.loads(subprocess.check_output(['node',str(HERE/'current_model.js')],
      input=json.dumps({'states':states,'slim':True}).encode()))

base_models={'F0':f0_batch([BASE])[0],**evaluate(BASE)}
results=[];family_summaries=[];checks={m:{} for m in MODELS}
for family,spec in FAMILIES.items():
    current=[];previous={m:base_models[m]['raw_score'] for m in MODELS};pass_count={m:0 for m in MODELS}
    for start in range(0,100,10):
        # Batches bound memory for lot-split representations (up to 3,131 rows).
        pairs=[create(family,i) for i in range(start,start+10)];states=[p[0] for p in pairs]
        existing=f0_batch(states)
        for offset,((s,param),old) in enumerate(zip(pairs,existing)):
            i=start+offset;models={'F0':old,**evaluate(s)};scores={}
            for m,r in models.items():
                assert r.get('status','ok')=='ok' and isinstance(r['raw_score'],(int,float)),(family,m,r)
                raw=r['raw_score'];reference=previous[m]
                if spec['expectation']=='equal_baseline':ok=abs(raw-base_models[m]['raw_score'])<=1e-7
                elif spec['expectation']=='nonincreasing':ok=raw<=reference+1e-7
                elif spec['expectation']=='nondecreasing':ok=raw>=reference-1e-7
                else:ok=None
                if ok is True:pass_count[m]+=1
                previous[m]=raw;scores[m]={'score':r['score'],'raw_score':raw,'behavior_pass':ok}
            reference_equity=spec.get('reference_equity',E)
            row={'family':family,'variant':i+1,'parameter':param,'net_equity':equity(s),
                'mark_change_from_baseline':equity(s)-reference_equity,'borrowing':sum(max(0,-a['cash']) for a in s['accounts']),'models':scores}
            current.append(row);results.append(row)
    if spec['expectation']: 
        for m in MODELS:checks[m][family]={'pass':pass_count[m],'total':100}
    summary={'family':family,'label':spec['label'],'count':100,'equity_first':current[0]['net_equity'],'equity_last':current[-1]['net_equity'],
        'last_change':current[-1]['mark_change_from_baseline'],'models':{}}
    for m in MODELS:
        values=sorted(r['models'][m]['raw_score'] for r in current)
        summary['models'][m]={'min':values[0],'median':(values[49]+values[50])/2,'max':values[-1],
           'first':current[0]['models'][m]['score'],'last':current[-1]['models'][m]['score'],
           'last_raw':current[-1]['models'][m]['raw_score'],'pass':pass_count[m] if spec['expectation'] else None}
    family_summaries.append(summary)
    print(family,'100 variants', {m:summary['models'][m]['last'] for m in MODELS},flush=True)

quality={}
for m in MODELS:
    behavioral={}
    for criterion,families in protocol['behavior_criteria'].items():
        count=sum(checks[m][f]['pass'] for f in families);total=100*len(families)
        behavioral[criterion]={'pass':count,'total':total,'points':10*count/total}
    behavior=sum(v['points'] for v in behavioral.values())
    quality[m]={'static':static_score(m),'behavior':behavior,'quality_score':static_score(m)+behavior,'checks':behavioral}

# Evaluate a transparent rescaling sensitivity; no model refitting.
weight_sensitivity=[]
for behavior_weight in [.3,.4,.5,.6,.7]:
    scores={m:quality[m]['behavior']/50*(100*behavior_weight)+quality[m]['static']/50*(100*(1-behavior_weight)) for m in MODELS}
    weight_sensitivity.append({'behavior_weight':behavior_weight,'scores':scores,'ranking':sorted(MODELS,key=lambda m:scores[m],reverse=True)})
account_results=evaluate_accounts(BASE)
out={'protocol':protocol,'baseline':base_models,'baseline_accounts_alternatives':account_results,'quality':quality,
     'ranking':sorted(MODELS,key=lambda m:quality[m]['quality_score'],reverse=True),
     'family_summaries':family_summaries,'formula_weight_sensitivity':weight_sensitivity,
     'scenario_count':len(results),'formula_evaluations':len(results)*len(MODELS),'largest_stock_issuer':largest,'results':results}
(HERE/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
with (HERE/'simulations.csv').open('w',newline='') as file:
    fields=['family','variant','parameter','net_equity','mark_change_from_baseline','borrowing']+[f'{m}_{suffix}' for m in MODELS for suffix in ['score','raw_score','behavior_pass']]
    writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
    for row in results:
        flattened={k:v for k,v in row.items() if k!='models'}
        for m,values in row['models'].items():
            for suffix,value in values.items():flattened[f'{m}_{suffix}']=value
        writer.writerow(flattened)
print('Quality:',quality)
print('Ranking:',out['ranking'],'evaluations',out['formula_evaluations'])
