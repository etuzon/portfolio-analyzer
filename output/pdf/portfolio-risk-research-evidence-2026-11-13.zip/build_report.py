"""Build the research report from executed results, without application changes."""
from collections import defaultdict
from html import escape
import json
import re
from pathlib import Path
import shutil

from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing, Line, PolyLine, String, Rect

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT/'output/pdf'
OUT.mkdir(parents=True,exist_ok=True)
R=json.loads((HERE/'results.json').read_text())
A=json.loads((HERE/'value_audit.json').read_text())
S=json.loads((HERE/'snapshot.json').read_text())
M=json.loads((HERE/'methodology_frozen.json').read_text())
SOURCES=json.loads((HERE/'methodology_sources.json').read_text())
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVuBold',italic='DejaVu',boldItalic='DejaVuBold')
NAVY=colors.HexColor('#12233E');BLUE=colors.HexColor('#1165AB');GRAY=colors.HexColor('#586779');LIGHT=colors.HexColor('#EEF3F8');ORANGE=colors.HexColor('#B35618')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='ReportTitle',fontName='DejaVuBold',fontSize=26,leading=32,textColor=NAVY,spaceAfter=16))
styles.add(ParagraphStyle(name='Heading',fontName='DejaVuBold',fontSize=17,leading=22,textColor=NAVY,spaceAfter=10,spaceBefore=4))
styles.add(ParagraphStyle(name='Sub',fontName='DejaVuBold',fontSize=11,leading=16,textColor=NAVY,spaceAfter=6,spaceBefore=11))
styles.add(ParagraphStyle(name='Body',fontName='DejaVu',fontSize=9.2,leading=14,spaceAfter=9,textColor=NAVY))
styles.add(ParagraphStyle(name='SmallText',fontName='DejaVu',fontSize=7.5,leading=11,spaceAfter=6,textColor=GRAY))
styles.add(ParagraphStyle(name='Cell',fontName='DejaVu',fontSize=8.2,leading=11,textColor=NAVY))
styles.add(ParagraphStyle(name='CellHead',fontName='DejaVuBold',fontSize=8,leading=11,textColor=colors.white))
styles.add(ParagraphStyle(name='Formula',fontName='DejaVu',fontSize=9.1,leading=15,textColor=BLUE,backColor=LIGHT,borderPadding=8,spaceAfter=12,spaceBefore=5))
story=[]
def p(text,style='Body'):
    # Keep prose word/number boundaries readable without modifying formula IDs,
    # file paths, numeric dates, or link attributes.
    text=re.sub(r'(?<=[a-uw-z])(?=\d)(?<!&#x)', ' ', text)
    return Paragraph(text,styles[style])
def add(text,style='Body'):story.append(p(text,style))
def heading(text):add(text,'Heading')
def sub(text):add(text,'Sub')
def gap(h=7):story.append(Spacer(1,h))
def money(v,dec=2):return f'₪{v:,.{dec}f}'
def pct(v):return f'{v*100:.2f}%'
def table(headers,rows,widths,small=False):
    data=[[p(escape(str(h)),'CellHead') for h in headers]]+[[p(escape(str(c)),'Cell') for c in row] for row in rows]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),
       ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
       ('TOPPADDING',(0,0),(-1,-1),7 if not small else 5),('BOTTOMPADDING',(0,0),(-1,-1),7 if not small else 5),
       ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,LIGHT]),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#D0DAE7'))]))
    story.append(t);gap(9)
def page():story.append(PageBreak())
def label(a):
    name=a['label'].split(' · ')[0]
    name={'פסגות':'Psagot','מיטב':'Meitav','הפניקס':'Phoenix','כלל ביטוח ופיננסים':'Clal'}.get(name,name)
    return name+' ...'+a['label'][-4:]
def line_chart(family,title):
    d=Drawing(492,184);left=35;bottom=30;w=440;h=118
    for y in [0,20,40,60]:
        yy=bottom+y/60*h;d.add(Line(left,yy,left+w,yy,strokeColor=colors.HexColor('#DDE5EE'),strokeWidth=.5));d.add(String(left-8,yy-3,str(y),fontName='DejaVu',fontSize=7,textAnchor='end',fillColor=GRAY))
    palette={'F0':'#B35618','F1':'#118272','F2':'#235BBA','F3':'#874BB0','F4':'#6B7682'}
    rows=[x for x in R['results'] if x['family']==family]
    for model in ['F2','F4','F3','F1','F0']:
        points=[]
        for i,row in enumerate(rows):points.extend([left+i/99*w,bottom+row['models'][model]['raw_score']/60*h])
        d.add(PolyLine(points,strokeColor=colors.HexColor(palette[model]),strokeWidth=1.8 if model=='F0' else 1))
    d.add(String(left,163,title,fontName='DejaVuBold',fontSize=9,fillColor=NAVY))
    d.add(String(left,14,'2 lots per position',fontName='DejaVu',fontSize=7,fillColor=GRAY))
    d.add(String(left+w,14,'101 lots per position',fontName='DejaVu',fontSize=7,textAnchor='end',fillColor=GRAY))
    for i,model in enumerate(['F0','F1','F2','F3','F4']):
        x=left+220+i*43;d.add(Line(x,177,x+11,177,strokeColor=colors.HexColor(palette[model]),strokeWidth=2));d.add(String(x+14,174,model,fontName='DejaVu',fontSize=7,fillColor=GRAY))
    return d

# 1: decision and scope.
add('Portfolio risk formula review','ReportTitle')
add('13/11/2026 | Research snapshot in ILS | 100 variants in each of 14 scenario families','SmallText')
add('<b>The current score is mathematically reproducible, but structurally unreliable.</b> The same assets and cash can score 31 or 17 merely by changing how position rows are represented. Use the stress-loss approach as the leading research candidate, and fix account coverage before presenting a whole-wealth score.')
table(['Scope','Reconciled value','Assessment'],[
 ['Investment portfolio',money(A['portfolio_value']),'31 positions; 4 funded accounts; current model 31/100'],
 ['Separate pension / savings',money(A['separate_funds_total']),'8 balances in 3 accounts; allocations unavailable'],
 ['Combined excluding employee equity',money(A['combined_wealth_excluding_esop']),'Balance sum only; whole-wealth risk unavailable']], [161,123,208])
sub('Three leading candidates, with the current formula included')
table(['Formula','Quality /100','Portfolio score /100','Financial meaning'],[
 ['1. F2: maximum stress loss','93','52','25.76% loss under the worst chosen illustrative shock'],
 ['2. F3: assumed factor risk','91','19','9.43% assumed annual risk proxy; uncalibrated'],
 ['3. F4: 70/30 hybrid','90','42','Blend of F2 and F3; exploratory composite'],
 ['F1: repaired heuristic','85','16','Smallest model repair; still a heuristic'],
 ['F0: current v2','54.75','31','Weighted heuristic with row/account sensitivity']], [155,62,77,198])
add('<b>These are two different scores.</b> Quality grades measure fit to the declared review rubric. Portfolio scores are model-specific scales. A lower score under a different formula does not mean the portfolio became safer. None of the quality grades measures forecast accuracy.','SmallText')
sub('What was actually executed')
add('1,400 deterministic portfolio variants × 5 formulas = <b>7,000 formula evaluations</b>, plus baselines and boundary examples. Each formula received 600 structural comparisons. The variants are sensitivity sweeps and representation checks, not independent market outcomes or a historical backtest.')
add('Recommended next model design: show stressed loss in ILS and percent, modeled debt by account, and data coverage as separate fields. Keep investment suitability and spending needs separate. This review leaves the application and saved portfolio unchanged.','SmallText')
page()

# 2: balance reconciliation.
heading('Account values and coverage')
add('The investment balances reconcile using current ledger quantities/cash and saved dated marks. Negative cash is counted as borrowing; none is recorded in this snapshot. USD is converted once at the saved 12/11/2026 rate of <b>3.1754 ILS per USD</b>. These are stored-value checks, not independent broker-statement verification.')
old_by_id={a['key']:a for a in R['baseline']['F0']['accounts']}
rows=[]
for a in A['current_accounts']:
    if a['type']!='Investment':continue
    aid=a['id'];rows.append([label(a),f"{a['currency']} {a['cash_native']:,.2f}",money(a['securities_value']),money(a['net_value']),old_by_id[aid]['risk']['score']])
rows.append(['Investment total',money(A['cash']),money(A['securities_value']),money(A['portfolio_value']),'31'])
table(['Account','Cash in account currency','Securities in ILS','Net value in ILS','F0 risk'],rows,[103,106,103,118,62])
sub('Balances excluded from the holdings risk calculation')
fund_by_account=defaultdict(float)
for f in A['separate_funds']:fund_by_account[f['account_id']]+=f['amount']
rows=[]
for a in A['current_accounts']:
    if a['type']=='Long-Term Savings':rows.append([label(a),money(fund_by_account[a['id']]),'Allocation and economic FX unavailable'])
table(['Savings account','Saved fund balance','Risk coverage'],rows,[145,130,217])
add(f"The omitted balances represent <b>{pct(A['separate_funds_total']/A['combined_wealth_excluding_esop'])}</b> of combined wealth excluding employee equity. The investment model therefore covers only <b>{pct(A['portfolio_value']/A['combined_wealth_excluding_esop'])}</b> of that balance total. Pension funds are not assumed to be cash, collateral, or freely transferable funds.")
sub('Freshness and source checks')
add('All 31 current positions match saved analyses in identity, quantity, cost basis, asset class and currency. Every saved market value equals quantity × normalized saved unit price. Cash transaction currencies match their accounts, and no future-dated transactions enter the calculation. The extracted JavaScript matches the deployed file hash.')
add('Material gaps: bond 121899CH9 uses a 31/07/2026 mark (105 days old); Treasury 91282CKD2 uses 06/11/2026; fund 5139324 and UNB use 11/11/2026; other stock marks use 12/11/2026. Separate fund balances date from 07/08/2026 or 15/08/2026. Accrued bond interest and clean/dirty price conventions are not independently verified.')
add('The saved analytics cache has a different revision signature from the current ledger. This review reconstructs a dated research input after checking the positions individually; it does not certify a fresh live API context or a current broker valuation. Employee equity is excluded throughout.','SmallText')
page()

# 3: current model and failures.
heading('Why the current 31 is questionable')
add('Current v2 is a declared heuristic, not a probability. It sums ten weighted components, amplifies them for borrowing, then blends pooled risk with account risks. The implementation is reproduced exactly in the research bundle.')
add('S = sum of actual component points, with maxima:<br/>concentration16, asset mix14, currency10, industry10, cash7, derivatives10, volatility10, horizon10, issuer/country8, data quality5<br/>R = round[min(100, S × (1 + D/E))]<br/>Total = round[0.75 × pooled R + 0.25 × gross-asset-weighted account R]','Formula')
add('E is signed net equity; D sums each account’s negative cash, so positive cash elsewhere cannot erase borrowing. With exposure or debt and E ≤ 0, the score is 100. Empty debt-free portfolios score 0. The current borrowing rule is a useful feature to preserve.','SmallText')
table(['Executed issue','Result','Financial implication'],[
 ['Identical lot splitting','31 → 17; no change in assets or equity','Concentration is partly calculated by row, so representation changes risk.'],
 ['Equivalent account repartition','Rounded scores range 31-33','The 25% account blend depends on account grouping.'],
 ['Cash sales at fixed equity','5 reversals in 200 ordered comparisons','Raw risk sometimes rises after moving long exposure to same-currency cash.'],
 ['Money-market-heavy Psagot account','Current 25; repaired heuristic 3','Wrapper concentration16 + issuer4 + long-horizon penalty3.5 dominate.']], [131,131,230])
story.append(line_chart('lot_split_invariance','Same economics, different position-row counts'))
add('The chart uses unrounded research scores; the unchanged baseline F0 is 31 before any split. Proposed models remain constant. A pass/fail comparison uses a 0.0000001-point tolerance; displayed integer plateaus do not hide raw-score movement.','SmallText')
add('Additional weaknesses: combined positive cash is assigned the base currency, understating the USD-cash component; the price-range proxy is not return volatility; sparse bond marks can create a zero range; and missing pension allocation is absent from the financial score. Excess cash and too little long-term equity are opportunity/suitability concerns and should be reported separately from market loss.','SmallText')
page()

# 4: candidates.
heading('Three leading formulas')
sub('1. F2 - maximum illustrative stress loss | quality 93/100')
add('For every selected shock, reprice the local instrument first, then apply its economic FX shock. Keep signed cash and borrowing in their actual currencies. Aggregate the largest nonnegative loss and divide by positive net equity.')
add('ΔE(s) = Σ V(i) × [(1 + r(i,s)) × (1 + f(i,s)) - 1] + Σ C(a) × f(a,s)<br/>L = max over s of [max(0, -ΔE(s))]<br/>F2 = min(100, 200 × L / E)','Formula')
add('The scale reaches 100 at a 50% loss under the chosen scenarios. The baseline maximum is <b>₪268,646.59 (25.76%)</b>, giving an unrounded score of 51.53, displayed as 52. The shock set is an instantaneous repricing exercise with no assigned probability or forecast horizon. It is not VaR, expected shortfall, or an exhaustive worst case.')
add('Frozen downside shocks: individual equities -50%; broad equities -40%; sector/country equity -50%; multi-asset -25%; money market -1%; government bond -12%; unclassified/IG bond -15%; HY bond -25%; property -40%; commodity -35%. FX paths include ±20% individually and jointly; market paths include both signs. Add individual-stock issuer ±100% scenarios; do not default a diversified fund wrapper as if it were a single stock. All magnitudes are analyst assumptions.')
sub('2. F3 - assumed factor risk | quality 91/100')
add('Express each position as ILS exposures to shared equity, rates, FX, and issuer/fund residual factors. Same-issuer residuals aggregate across accounts and lots. Independent factors produce a positive semidefinite covariance structure; their independence and coefficients remain unverified assumptions.')
add('σ(proxy) = sqrt[Σ factor-ILS-exposure(k)²] / E<br/>F3 = min(100, 200 × σ(proxy))','Formula')
add('Baseline proxy: <b>9.43%</b>, giving 18.86, displayed as 19. Common factor assumptions: equity18%, rates8%, each foreign currency12%. Stock residual30%, government-bond residual2%, unclassified-bond residual4%, money-market residual0.5%; detailed betas are in the frozen methodology. This is not measured historical or forecast annual volatility.')
sub('3. F4 - stress / factor hybrid | quality 90/100')
add('F4 = 0.70 × capped F2 + 0.30 × capped F3<br/>Baseline = 0.70 × 51.5281 + 0.30 × 18.8607 = 41.7279 → 42','Formula')
add('The hybrid combines downside stress and diversification sensitivity, but its 70/30 mix and aligned score scales have no empirical validation. It ranks third under this rubric; prefer F2 and F3 shown separately for decisions. F1, the repaired heuristic, is the smaller implementation option: group issuers, discount fund wrappers, use cash-aware denominators, and remove opportunity-cost penalties and the account blend. Its quality is85 and baseline score16.','SmallText')
page()

# 5: scenario outcomes.
heading('100 simulations per scenario family')
add('Every family contains exactly 100 deterministic variants; every formula uses the same state in each variant. The table reports the final endpoint score. Detailed raw scores for all 1,400 cases are included in the CSV. Composition changes use frozen marks; no tax, fees, slippage, interest or trading constraints are modeled.','SmallText')
short_labels={
 'equity_to_cash':'Sell 100% of USD equities to USD cash',
 'money_market_to_cash':'Redeem 100% of ILS money fund to cash',
 'debt_funded_buy':'Buy equities equal to50% of initial equity',
 'issuer_concentration':'Consolidate100% of stock book into CMRE',
 'equity_drawdown':'All equities -60%; FX unchanged',
 'usd_depreciation':'USD/ILS -30%; local prices unchanged',
 'bond_mark_decline':'All bond marks -20%',
 'joint_market_fx':'Equities -50%, bonds -15%, USD -25%',
 'largest_issuer_failure':'CMRE -100%; others unchanged',
 'cash_injection':'External ILS cash equals100% initial equity',
 'scale_invariance':'Assets and cash scaled to10 times',
 'lot_split_invariance':'101 identical lots per position',
 'account_partition_invariance':'Equivalent USD subaccounts, variant100',
 'unknown_fund_allocation':'Assume all omitted funds USD broad equity'}
rows=[]
for f in R['family_summaries']:rows.append([short_labels[f['family']]]+[f['models'][m]['last'] for m in ['F0','F1','F2','F3','F4']])
table(['Endpoint - 100 cases each','F0','F1','F2','F3','F4'],rows,[287,41,41,41,41,41],small=True)
add('<b>Post-shock risk is not the loss that just occurred.</b> After an equity crash, remaining equity exposure is smaller relative to unchanged ILS cash/money funds. A recalculated score can fall even though the investor has suffered a loss. The P&amp;L below measures that loss directly.','SmallText')
loss_families=['equity_drawdown','usd_depreciation','bond_mark_decline','joint_market_fx','largest_issuer_failure']
rows=[]
for f in R['family_summaries']:
    if f['family'] in loss_families:rows.append([short_labels[f['family']],money(f['last_change']),pct(f['last_change']/A['portfolio_value']),money(f['equity_last'])])
table(['Shock endpoint','Change in value','% initial equity','Remaining equity'],rows,[213,100,77,102],small=True)
add('External cash additions and artificial portfolio scaling are not investment profits. Conditional fund allocations change modeled coverage; their value is not added P&amp;L. Lot/account representation cases leave equity unchanged. Bond shocks are mark sensitivities, not an assumed basis-point/duration calculation.','SmallText')
page()

# 6: quality scoring.
heading('How formula quality was scored')
add('The rubric was frozen before executing the sweeps. Half the grade comes from executed structural behavior; half is judgmental design quality. This identifies arithmetic and design weaknesses, not the formula most likely to predict future losses.')
rows=[]
criteria=[('scale_invariance','Scale invariance'),('lot_split_invariance','Same-security lot split'),('cash_sale_monotonicity','Cash-sale monotonicity'),('leverage_monotonicity','Borrowing purchase monotonicity'),('account_partition_invariance','Equivalent account repartition')]
for key,text in criteria:rows.append([text]+[f"{R['quality'][m]['checks'][key]['pass']}/{R['quality'][m]['checks'][key]['total']}" for m in ['F0','F1','F2','F3','F4']])
table(['Behavioral comparisons','F0','F1','F2','F3','F4'],rows,[217,55,55,55,55,55],small=True)
add('Each behavioral criterion earns10 × its pass fraction. The cash criterion includes100 equity-sale and100 money-fund-redemption comparisons. Leverage purchases hold equity fixed and spend positive account cash before borrowing. Lot tests preserve each issuer, quantity and currency exposure; repartitions retain account currency and horizon and create no debt.','SmallText')
rows=[]
for section,text,maximum in [('interpretability','Interpretability',20),('evidence_coverage','Evidence and coverage',20),('scenario_breadth','Risk-channel breadth',10)]:
    rows.append([text+f' /{maximum}']+[sum(x[m] for x in M['static_rubric'][section].values()) for m in ['F0','F1','F2','F3','F4']])
rows.append(['Executed behavior /50']+[f"{R['quality'][m]['behavior']:.2f}" for m in ['F0','F1','F2','F3','F4']])
rows.append(['Total quality /100']+[f"{R['quality'][m]['quality_score']:.2f}" for m in ['F0','F1','F2','F3','F4']])
table(['Quality component','F0','F1','F2','F3','F4'],rows,[217,55,55,55,55,55],small=True)
sub('What the static grade rewards')
add('Interpretability allocates5 points each to meaningful output units, explicit coefficients, attribution, and separating downside from suitability. Evidence allocates5 each to a dated input snapshot, signed cash/FX handling, empirical calibration, and unsupported/missing inputs. Breadth allocates2 each to equities, bonds, FX, funding, and issuer concentration. The full subcriterion allocations are retained in methodology_frozen.json.')
add('<b>Every model receives zero for empirical calibration.</b> None has been fitted or tested on a chronological holdout of observed losses. All receive only partial funding credit: spending needs, settlement restrictions, verified margin requirements and pension liquidity are absent. Stale marks and missing fund allocations remain material regardless of the quality score.')
sub('Sensitivity and limits of the ranking')
add('Reweighting behavioral versus static grades from30/70 to70/30 preserves the order F2, F3, F4, F1, F0. This checks that one category weight does not reverse the result. It does not prove robustness to different subjective subgrades or shock coefficients. F2’s two-point lead over F3 is a design preference, not statistical significance.')
add('The 100 variants in each family are deliberately related. More variants improve coverage of implementation behavior, but do not supply100 independent financial outcomes or confidence intervals. Prospective loss validation still requires dated, adjusted price/FX histories and a frozen scoring-to-outcome contract.','SmallText')
page()

# 7: financial interpretation and uncertainty.
heading('Financial interpretation and missing coverage')
equity_value=sum(x['value'] for x in S['positions'] if x['asset_class']=='EQUITY')
bond_value=sum(x['value'] for x in S['positions'] if x['asset_class']=='BOND')
mm_value=sum(x['value'] for x in S['positions'] if x['asset_focus']=='money_market')
usd=sum(x['value']*x['currency_exposures'].get('USD',0) for x in S['positions'])+sum(a['cash'] for a in S['accounts'] if a['currency']=='USD')
table(['Modeled allocation','Value in ILS','Share of modeled equity'],[
 ['Individual equities',money(equity_value),pct(equity_value/A['portfolio_value'])],
 ['Bonds',money(bond_value),pct(bond_value/A['portfolio_value'])],
 ['ILS money-market fund',money(mm_value),pct(mm_value/A['portfolio_value'])],
 ['Cash',money(A['cash']),pct(A['cash']/A['portfolio_value'])],
 ['USD exposure proxy (overlaps above)',money(usd),pct(usd/A['portfolio_value'])]], [242,130,120])
add('The USD exposure estimate follows saved currency classifications and each stock’s quote-currency proxy. It is not verified revenue-currency look-through. A 20% USD decline alone reduces modeled equity by about10.58% before any local price move. Fund liquidity, bank deposit risk and inflation risk remain separate from the market-shock score.')
sub('Account risk under each formula')
rows=[]
for a in A['current_accounts']:
    if a['type']=='Investment':rows.append([label(a),old_by_id[a['id']]['risk']['score']]+[R['baseline_accounts_alternatives'][a['id']][m]['score'] for m in ['F1','F2','F3','F4']])
table(['Account','Current F0','F1','F2','F3','F4'],rows,[217,55,55,55,55,55])
add('The low market-risk estimate for the ILS money-fund account should not be read as zero risk or a personal allocation recommendation. Conversely, scores near100 in USD-equity accounts reflect the chosen50%-equity/20%-FX shock and score scaling, not a prediction that the account will fail.','SmallText')
sub('100 conditional allocations for the unmodeled funds')
f=next(x for x in R['family_summaries'] if x['family']=='unknown_fund_allocation')
add(f"Keeping the recorded {money(A['separate_funds_total'])} fund balance fixed, the review sweeps an assumed0%-100% unhedged USD broad-equity share; the remainder is assumed ILS money market. Across100 cases, whole-wealth F2 ranges from <b>{f['models']['F2']['min']:.2f} to {f['models']['F2']['max']:.2f}</b>, equivalent to <b>{f['models']['F2']['min']/2:.2f}%-{f['models']['F2']['max']/2:.2f}%</b> loss under the selected shocks.")
add('This is a conditional illustration, not a bound on actual fund risk: the real allocation may lie outside those assumptions, include other currencies or instruments, or face restrictions. No whole-wealth baseline risk is assigned. Obtain dated fund holdings/exposure reports and refresh the balances before adopting one.')
add('Bonds need instrument-specific follow-up. The stored name of121899CH9 suggests a2045 maturity, but issuer, duration, credit quality and clean/dirty price basis were not independently established. Sparse constant marks produce a zero range in the current formula. A generic15% stress or assumed rate factor cannot certify its true downside. The100 bond-mark sensitivities separately span0.2%-20% declines.','SmallText')
page()

# 8: worked example, references, reproducibility.
heading('Worked example, evidence, and reproduction')
sub('Joint stress arithmetic on the frozen investment snapshot')
stock_loss=equity_value*.6
gov=sum(p_['value'] for p_ in S['positions'] if p_['asset_focus']=='government_bond')
other=bond_value-gov
usdcash=sum(a_['cash'] for a_ in S['accounts'] if a_['currency']=='USD')
parts=[('USD individual stocks: (0.50 × 0.80) - 1',equity_value*.6),
       ('USD government bond: (0.88 × 0.80) - 1',gov*.296),
       ('USD unclassified bond: (0.85 × 0.80) - 1',other*.32),
       ('USD cash: 20% FX loss',usdcash*.2),('ILS money market:1% mark loss',mm_value*.01)]
table(['Selected stress component','Illustrative loss'],[[name,money(value)] for name,value in parts]+[['Total',money(sum(v for _,v in parts))]],[345,147],small=True)
add('The stock loss is60%, rather than70%, because local-price and FX returns compound. Total loss / ₪1,042,717.80 =25.7641%; ×200 gives51.5281. The100 joint-sweep endpoint on page5 is more severe (USD -25%) than this formula’s reference FX shock (-20%), so its realized illustrative loss can exceed the reference catalogue result.','SmallText')
sub('Primary methodology references')
for i,source in enumerate(SOURCES,1):
    title=source['title'].replace('’',"'")
    add(f"{i}. <link href=\"{escape(source['url'],quote=True)}\" color=\"#1165AB\">{escape(title)}</link><br/>{escape(source['supports'])}",'SmallText')
add('Retrieved13/11/2026. These sources support risk mechanisms and documenting assumptions. They do not endorse the formulas, shock sizes, scores, fund classifications or broker permissions in this report. US money-market guidance is general context, not verification of Israeli fund5139324. No web search snippet is used as a current valuation.','SmallText')
sub('Reproduction and scope of verification')
add('Run from the repository root:<br/><font size="8">./.venv/bin/python .runtime/risk-formula-review-2026-11-13/prepare.py<br/>./.venv/bin/python .runtime/risk-formula-review-2026-11-13/run_review.py<br/>./.venv/bin/python .runtime/risk-formula-review-2026-11-13/build_report.py</font>','SmallText')
add('The evidence directory retains input.json, snapshot.json, current_model.js, candidate_formulas.py, protocol.json, methodology_frozen.json, value_audit.json, financial_examples.json, results.json and simulations.csv. Capture uses read-only database connections and rejects a moving source. Research scripts and output remain local; no formula was installed, no ledger corrected, no trade submitted, and no deployment performed.','SmallText')
add('Verification includes exact-model execution, source-to-ledger reconciliation, structural simulation invariants and 23 raw-source arithmetic checks by the dedicated financial analyst. That analyst authored the candidate methods; the raw-source review is a cross-check of the coordinator’s reconciliation and simulations, not a separate independent audit of the analyst’s models. No historical forecast validation, broker-statement reconciliation, or live-browser acceptance test is claimed.','SmallText')

def footer(c,doc):
    c.setStrokeColor(colors.HexColor('#D0DAE7'));c.line(46,38,549,38)
    c.setFont('DejaVu',7);c.setFillColor(GRAY)
    c.drawString(46,26,'Portfolio risk research | 13/11/2026 | ILS | Saved valuations')
    c.drawRightString(549,26,str(doc.page))
target=OUT/'portfolio-risk-formula-review-2026-11-13.pdf'
doc=SimpleDocTemplate(str(target),pagesize=(595.28,841.89),leftMargin=51,rightMargin=51,
    topMargin=45,bottomMargin=54,title='Portfolio risk formula review - 13/11/2026',author='Portfolio analysis research')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
shutil.copyfile(HERE/'simulations.csv',OUT/'portfolio-risk-simulations-2026-11-13.csv')
print(target)
