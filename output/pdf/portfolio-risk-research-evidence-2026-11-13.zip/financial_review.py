"""Independent arithmetic review of source cash/value and simulation outputs.

Does not import the candidate formula module or scenario generator. Explicit
coefficient calculations below independently apply the declared stress contract.
Run: ./.venv/bin/python .runtime/risk-formula-review-2026-11-13/financial_review.py
"""
from collections import Counter,defaultdict
from copy import deepcopy
import json,math,subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
source=json.loads((HERE/'input.json').read_text())
state=json.loads((HERE/'snapshot.json').read_text())
results=json.loads((HERE/'results.json').read_text())
audit=json.loads((HERE/'value_audit.json').read_text())
checks=[]
def check(name,actual,expected,absolute=1e-6):
    passed=math.isclose(actual,expected,abs_tol=absolute,rel_tol=1e-10)
    checks.append({'check':name,'actual':actual,'expected':expected,'passed':passed})
    assert passed,(name,actual,expected)

usd_rows=[r for r in source['fx_saved'] if r['pair']=='USD/ILS' and r['provider']=='frankfurter_fx']
usd_rate=max(usd_rows,key=lambda r:r['updated_at'])['quote']['rate']
rate={'ILS':1,'USD':usd_rate}
accounts={a['id']:a for a in source['accounts'] if a['type']!='ESOP'}
sign={'BUY':-1,'CASH_OUT':-1,'FEE':-1,'SELL':1,'SHORT':1,'DIVIDEND':1,'INTEREST':1,'CASH_IN':1}
cash={aid:a['initial_cash'] for aid,a in accounts.items()}
for tx in source['transactions']:
    aid=tx['account_db_id']
    if aid in accounts and tx['action'] in sign:
        assert tx['currency']==accounts[aid]['currency'] or tx['quantity']*tx['price']==0
        cash[aid]+=sign[tx['action']]*tx['quantity']*tx['price']
cash_base={aid:amount*rate[accounts[aid]['currency']] for aid,amount in cash.items()}
position_values=defaultdict(float);values_by_class=defaultdict(float);pnl_by_account=defaultdict(float)
native_value_total=defaultdict(float)
position_count=0
for item in source['items']:
    h=item['holding'];aid=h['account_id']
    if aid not in accounts or h['asset_class'] in {'RSU','STOCK_OPTION','EMPLOYEE_STOCK_OPTION'}:continue
    position_count+=1
    value=h['market_value']*rate[h['currency']]
    position_values[aid]+=value;values_by_class[h['asset_class']]+=value
    native_value_total[h['currency']]+=value
    # Current source has only US stocks, two US bonds and one ILS money fund.
    if h['asset_class']=='EQUITY':market_loss=.5
    elif h['symbol']=='91282CKD2':market_loss=.12
    elif h['symbol']=='121899CH9':market_loss=.15
    elif h['symbol']=='5139324':market_loss=.01
    else:raise AssertionError(('unsupported source',h['symbol']))
    fx_loss=.2 if h['currency']=='USD' else 0
    pnl_by_account[aid]+=value*((1-market_loss)*(1-fx_loss)-1)
for aid,value in cash_base.items():
    if accounts[aid]['currency']=='USD':pnl_by_account[aid]-=.2*value

cash_total=math.fsum(cash_base.values());securities_total=math.fsum(position_values.values())
equity=cash_total+securities_total
joint_loss=-math.fsum(pnl_by_account.values())
usd_exposure=native_value_total['USD']+sum(v for aid,v in cash_base.items() if accounts[aid]['currency']=='USD')
check('source position count',position_count,31)
check('cash from raw initial balances and signed transactions',cash_total,audit['cash'])
check('securities from raw native valuations and saved dated FX',securities_total,audit['securities_value'])
check('equity from independently reconstructed cash and values',equity,audit['portfolio_value'])
check('joint market and FX stress loss: independent raw-source repricing',joint_loss,results['baseline']['F2']['components']['maximum_stress_loss'])
check('F2 stress raw score from raw-source loss/equity',200*joint_loss/equity,results['baseline']['F2']['raw_score'])
check('stress P&L sums across every account',sum(pnl_by_account.values()),-joint_loss)
for a in state['accounts']:
    check('account cash '+a['label'],a['cash'],cash_base[a['id']])

# Independently derive factor exposures for this source universe. Factors are
# assumption-based; this check validates arithmetic rather than calibration.
stock_issuers=defaultdict(float)
for p in state['positions']:
    if p['asset_class']=='EQUITY':stock_issuers[p['issuer']]+=p['value']
stocks=values_by_class['EQUITY']
corporate=next(p['value'] for p in state['positions'] if p['symbol']=='121899CH9')
treasury=next(p['value'] for p in state['positions'] if p['symbol']=='91282CKD2')
money=values_by_class['MUTUALFUND']
factor_variance=(.18*(stocks+.1*corporate))**2+(.08*(corporate+treasury))**2+(.12*usd_exposure)**2
factor_variance+=sum((.30*v)**2 for v in stock_issuers.values())+(.04*corporate)**2+(.02*treasury)**2+(.005*money)**2
factor_sigma=math.sqrt(factor_variance)/equity
check('F3 independent factor variance and signed cash-FX aggregation',200*factor_sigma,results['baseline']['F3']['raw_score'])

# Counterexample independently constructs identical lots; uses current engine,
# not the candidate model or scenario-generation code.
split=deepcopy(state);split['positions']=[]
for p in state['positions']:
    for _ in range(101):
        q=deepcopy(p);q['value']/=101;q['quantity']/=101;split['positions'].append(q)
old=json.loads(subprocess.check_output(['node',str(HERE/'current_model.js')],input=json.dumps({'states':[state,split],'slim':True}).encode()))
check('same-economic-lot equity retained',sum(p['value'] for p in split['positions'])+sum(a['cash'] for a in split['accounts']),equity)
check('current score baseline independently executed',old[0]['score'],31)
check('current score 101-lot representation independently executed',old[1]['score'],17)

family_counts=Counter(row['family'] for row in results['results'])
assert len(family_counts)==14 and set(family_counts.values())=={100}
check('executed scenario states',len(results['results']),1400)
check('five formulas per scenario',sum(len(row['models']) for row in results['results']),7000)
for family in family_counts:
    rows=[r for r in results['results'] if r['family']==family]
    assert len({r['parameter'] for r in rows})==100
    if results['protocol']['families'][family]['equity_invariant']:
        assert all(math.isclose(r['net_equity'],equity,abs_tol=1e-5) for r in rows)

# Whole-wealth conditional endpoints independently rebuild the very different
# hypothetical allocations of the otherwise unknown pension/savings holdings.
fund_total=sum(f['amount'] for f in source['tables']['funds'])
check('fund amount sum from independent raw table',fund_total,audit['separate_funds_total'])
wealth=equity+fund_total
conditional_low=200*(joint_loss+.01*fund_total)/wealth
conditional_high=200*(joint_loss+(1-.6*.8)*fund_total)/wealth
conditional=next(f for f in results['family_summaries'] if f['family']=='unknown_fund_allocation')
check('conditional all-ILS-money-fund endpoint',conditional_low,conditional['models']['F2']['min'])
check('conditional all-USD-broad-equity endpoint',conditional_high,conditional['models']['F2']['max'])

out={'status':'complete financial research review; not software QA or empirical model validation',
 'checks':checks,'check_count':len(checks),'all_passed':all(c['passed'] for c in checks),
 'raw_source_equity':equity,'cash':cash_total,'securities':securities_total,
 'joint_stress_loss':joint_loss,'joint_stress_loss_fraction':joint_loss/equity,
 'joint_stress_account_pnl':dict(pnl_by_account),'usd_net_exposure':usd_exposure,
 'usd_exposure_fraction':usd_exposure/equity,'usd20pct_loss':usd_exposure*.2,
 'assumed_factor_sigma':factor_sigma,'fund_total':fund_total,'wealth_excluding_esop':wealth,
 'modeled_wealth_fraction':equity/wealth,'unmodeled_wealth_fraction':fund_total/wealth,
 'conditional_fullwealth_F2_interval':[conditional_low,conditional_high],
 'counterexample':{'original_score':old[0]['score'],'identical_lots_score':old[1]['score'],'lots':101,'changed_economic_exposure':False},
 'report_requirements':[
   'Qualify total as saved-mark value; old corporate bond mark and pension observations are not live certified wealth.',
   'Current31 and all proposed baseline risk scores cover modeled securities/cash, not the3.202m separate pension/savings exposures.',
   'The14families include economic changes, representation tests and explicitly hypothetical fund allocations; do not call1400independent market observations.',
   'Joint realized scenario loss is separate from post-shock remaining-portfolio risk: a lower post-crash score does not undo the loss.',
   'F2=52 means25.764% modeled stress loss under selected assumptions; F3=19 means9.43% assumed factor sigma; the scales are not interchangeable.',
   'Formula quality scores are frozen judgmental design-fit grades plus structural pass rates, never predictive accuracy.',
   'F4 is an exploratory70/30blend with no independently calibrated optimality claim.',
   'Bond ratings/duration/accruals, tax/slippage/financing, liquidity needs and pension access are unknown or excluded; no broker margin eligibility inferred.',
   'Simple USD exposure here is mechanical USD repricing, not issuer-revenue currency look-through.'
 ]}
(HERE/'financial_review.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k] for k in ['all_passed','check_count','joint_stress_loss','usd_net_exposure','modeled_wealth_fraction','conditional_fullwealth_F2_interval']},indent=2))
