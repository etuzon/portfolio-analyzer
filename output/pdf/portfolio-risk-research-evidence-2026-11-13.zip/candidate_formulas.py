"""Frozen research candidates; never imported by the application.

Protocol version: risk-review-20261113-v1. All money is signed ILS (or the
declared common base currency); currency weights are FRACTIONS, not percent.
The raw scores are synthetic model scales, not loss probabilities, forecasts,
calibrated VaR, or broker margin rules. No parameters are fitted to simulation
outputs. F2 and F3 coefficients below are explicitly analyst assumptions.

State: {base_currency, positions:[{account_id,symbol,issuer,value,asset_class,
asset_focus,industry,country,currency_exposures:{USD:1},unknown_currency,
volatility_proxy,derivative,diversified,missing:[]}], accounts:[{id,cash,currency}]}.
Scores exclude household pension fund balances missing from positions; such
balances MUST be reported separately rather than assigned an invented risk.
"""
from __future__ import annotations

from collections import defaultdict
import math

VERSION = "risk-review-20261113-v1"
NAMES = {"F1": "Repaired exposure heuristic", "F2": "Maximum illustrative stress loss",
         "F3": "Assumed factor risk", "F4": "70% stress / 30% factor hybrid"}
ASSET_FACTORS = {"money_market": .12, "government_bond": .2, "bond_unclassified": .35,
    "investment_grade_bond": .35, "high_yield_bond": .6, "broad_equity": .65,
    "single_equity": .65, "single_country_equity": .75, "sector_equity": .8,
    "multi_asset": .5, "real_estate": .7, "commodity": .85,
    "crypto": .95, "other": .7}
# Illustrative joint market decline magnitudes, not estimates of future losses.
STRESS_LOSS = {"money_market": .01, "government_bond": .12, "bond_unclassified": .15,
    "investment_grade_bond": .15, "high_yield_bond": .25,
    "broad_equity": .40, "single_equity": .50,
    "single_country_equity": .50, "sector_equity": .50,
    "multi_asset": .25, "real_estate": .40, "commodity": .35,
    "crypto": .70, "other": .50}
# Each tuple is (global-equity beta, common-rate beta, residual sigma).
# Equity sigma=.18, rates sigma=.08, each currency sigma=.12, independent
# factors. Residuals of the same issuer are perfectly correlated; diversified
# fund wrappers share focus residuals, so wrapper splitting gives no new hedge.
FACTOR_LOADINGS = {"money_market": (0,0,.005), "government_bond": (0,1,.02), "bond_unclassified": (.1,1,.04),
    "investment_grade_bond": (.1,1,.04), "high_yield_bond": (.4,.75,.10),
    "broad_equity": (1,0,.03), "single_equity": (1,0,.30),
    "single_country_equity": (1.1,0,.10), "sector_equity": (1.1,0,.15),
    "multi_asset": (.5,.5,.04), "real_estate": (.9,.5,.15),
    "commodity": (.3,0,.20), "crypto": (1.5,0,.60), "other": (1,.25,.35)}

# Static rubric frozen before running portfolio simulations. Each criterion is
# 0..5, except scenario breadth (five subcriteria, 0..2). Behavioral tests add
# up to 50; main runner supplies actual pass rates. These values are judgmental
# design-fit grades, not measured financial forecast accuracy.
STATIC_RUBRIC = {
    "interpretability": {"units": {"F0":0,"F1":0,"F2":5,"F3":3,"F4":2},
        "coefficients": {"F0":5,"F1":5,"F2":5,"F3":5,"F4":5},
        "attribution": {"F0":5,"F1":5,"F2":5,"F3":5,"F4":5},
        "downside_vs_suitability": {"F0":0,"F1":5,"F2":5,"F3":5,"F4":5}},
    "evidence_coverage": {"dated_snapshot": {"F0":5,"F1":5,"F2":5,"F3":5,"F4":5},
        "signed_cash_and_fx": {"F0":2,"F1":4,"F2":5,"F3":5,"F4":5},
        "empirically_calibrated": {"F0":0,"F1":0,"F2":0,"F3":0,"F4":0},
        "unsupported_and_unknown": {"F0":2,"F1":4,"F2":4,"F3":4,"F4":4}},
    "scenario_breadth": {"equity": {"F0":2,"F1":2,"F2":2,"F3":2,"F4":2},
        "bond": {"F0":1,"F1":1,"F2":2,"F3":2,"F4":2},
        "fx": {"F0":1,"F1":1,"F2":2,"F3":2,"F4":2},
        "funding": {"F0":1,"F1":1,"F2":1,"F3":1,"F4":1},
        "issuer": {"F0":1,"F1":2,"F2":2,"F3":2,"F4":2}},
}
RUBRIC_NOTE = ("Judgmental predeclared design-fit scores. Signed-cash/FX F0 loses "
    "points because combined cash is assigned base currency; F1 uses exposure "
    "heuristics rather than FX repricing. No model earns empirical calibration "
    "points. Funding is partial for all: no verified broker terms, cash-flow "
    "needs, liquidity haircuts, or pension transfer permissions. Unsupported/"
    "unknown and dated-snapshot scores concern the normalized research wrapper; "
    "they do not certify the live application or freshness of every quote.")

def static_score(model):
    return sum(grade[model] for section in STATIC_RUBRIC.values() for grade in section.values())

def _number(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)

def _focus(p):
    focus = p.get("asset_focus")
    if focus in ASSET_FACTORS:
        return focus
    asset = str(p.get("asset_class","")).upper()
    if asset in {"EQUITY","STOCK","RSU"}: return "single_equity"
    # Generic saved bonds are not silently labelled investment grade. The
    # coefficients for this separate bucket are declared research assumptions;
    # rating, duration and coupon/accrual evidence remain unverified.
    if asset in {"BOND","BONDS"}: return "bond_unclassified"
    if asset in {"ETF","MUTUALFUND"}: return "broad_equity" if p.get("diversified") else "other"
    if asset == "CRYPTO": return "crypto"
    if asset == "COMMODITY": return "commodity"
    return "other"

def _prepare(state):
    base = state.get("base_currency","ILS")
    positions, accounts = state.get("positions",[]), state.get("accounts",[])
    gaps=[]
    ids={str(a.get("id")) for a in accounts}
    for i,a in enumerate(accounts):
        if not _number(a.get("cash")): gaps.append(f"account_cash:{i}")
        if a.get("cash") and not a.get("currency"): gaps.append(f"account_currency:{i}")
    for i,p in enumerate(positions):
        if not _number(p.get("value")): gaps.append(f"position_value:{i}"); continue
        if not p["value"]: continue
        if str(p.get("account_id")) not in ids: gaps.append(f"account_identity:{i}")
        if not p.get("asset_class"): gaps.append(f"asset_class:{i}")
        elif str(p.get("asset_class","")).upper() not in {"EQUITY","STOCK","RSU","BOND","BONDS","ETF","MUTUALFUND","CRYPTO","COMMODITY","OTHER"}:
            gaps.append(f"unsupported_asset_class:{i}")
        if not p.get("issuer") and not p.get("symbol"): gaps.append(f"issuer_identity:{i}")
        if p.get("derivative") or str(p.get("asset_class","")).upper() in {"OPTION","FUTURE","STOCK_OPTION","EMPLOYEE_STOCK_OPTION"}:
            gaps.append(f"unsupported_derivative:{i}")
        allocations=p.get("currency_exposures")
        if not isinstance(allocations,dict) or any(not _number(x) or x<0 for x in allocations.values()):
            gaps.append(f"currency_exposure:{i}"); continue
        unknown=p.get("unknown_currency",0)
        if not _number(unknown) or unknown>1e-9 or abs(sum(allocations.values())-1)>1e-8:
            gaps.append(f"unknown_currency:{i}")
    if gaps: return None, sorted(set(gaps))
    holdings=sum(abs(p["value"]) for p in positions)
    cash_positive=sum(max(0,a["cash"]) for a in accounts)
    debt=sum(max(0,-a["cash"]) for a in accounts)
    equity=sum(p["value"] for p in positions)+sum(a["cash"] for a in accounts)
    return dict(base=base,positions=positions,accounts=accounts,holdings=holdings,
                cash_positive=cash_positive,debt=debt,equity=equity,gross=holdings+cash_positive), []

def _output(model,raw,ctx,**extra):
    score=min(100,max(0,raw))
    return {"model":model,"name":NAMES[model],"version":VERSION,
        "status":"ok","score":math.floor(score+.5),"raw_score":score,
        "equity":ctx["equity"],"debt":ctx["debt"],**extra}

def _boundary(model,ctx):
    if ctx["equity"]<=0:
        return _output(model,100 if ctx["gross"] or ctx["debt"] else 0,ctx,
                       components={"nonpositive_equity":bool(ctx["gross"] or ctx["debt"])})
    return None

def repaired_heuristic(ctx):
    """F1: current weights with grouped lots and cash-aware downside terms.

    Drop opportunity-cost cash/horizon penalties and keep data confidence out of
    financial risk. Use common gross-assets denominators throughout; group
    duplicated issuers before top/HHI. Fund wrapper factor=.05 money market,
    .35 other explicitly diversified funds, 1 otherwise. Total is direct pooled
    risk rather than a blend with arbitrary account partitions.
    """
    boundary=_boundary("F1",ctx)
    if boundary:return boundary
    rows=ctx["positions"]; gross=ctx["gross"]; base=ctx["base"]
    if not gross:return _output("F1",0,ctx,components={})
    issuers=defaultdict(float); industries=defaultdict(float); countries=defaultdict(float)
    fx=defaultdict(float); weighted_asset=ctx["cash_positive"]*.05; weighted_vol=0;short=False
    missing_industry=0
    for p in rows:
        value=abs(p["value"]); focus=_focus(p);issuer=p.get("issuer") or p["symbol"]
        diversified=bool(p.get("diversified"))
        wrapper=.05 if diversified and focus=="money_market" else .35 if diversified else 1
        issuers[issuer]+=value*wrapper
        weighted_asset+=value*ASSET_FACTORS[focus]
        vol=p.get("volatility_proxy")
        # Fallback is a declared assumption, not an observed annual volatility.
        vol=vol if _number(vol) and vol>=0 else (12 if focus=="money_market" else 14 if "bond" in focus else 24 if diversified else 48)
        weighted_vol+=value*min(vol,120)
        for currency,weight in p["currency_exposures"].items():fx[currency]+=p["value"]*weight
        equitylike=focus not in {"money_market","government_bond","investment_grade_bond","high_yield_bond","bond_unclassified"}
        if equitylike:
            industry=p.get("industry")
            if industry:industries[industry]+=value
            else:missing_industry+=value
        if p.get("country"):countries[p["country"]]+=value
        short=short or p["value"]<0
    for a in ctx["accounts"]:fx[a.get("currency",base)]+=a["cash"]
    shares=[x/gross for x in issuers.values()]
    top=max(shares,default=0);hhi=sum(x*x for x in shares)
    foreign=[abs(x)/gross for currency,x in fx.items() if currency!=base]
    cash_pct=ctx["cash_positive"]/gross
    components={
        "concentration":10*min(top/.4,1)+6*min(hhi/.25,1),
        "asset_mix":14*weighted_asset/gross,
        "currency":7*min(sum(foreign)/.8,1)+3*min(max(foreign,default=0)/.6,1),
        "industry":7*min(sum((v/gross)**2 for v in industries.values())/.3,1),
        "cash":7*max(0,(.05-cash_pct)/.05),
        "derivatives":2 if short else 0,
        "volatility":10*min(weighted_vol/gross/60,1),
        "horizon":0,
        "issuer_country":4*min(top/.35,1)+4*max(0,min((max(countries.values(),default=0)/gross-.55)/.35,1)),
        "data_quality":0,
    }
    unlevered=sum(components.values())
    components["borrowing"]=max(0,min(100-unlevered,unlevered*ctx["debt"]/ctx["equity"]))
    return _output("F1",sum(components.values()),ctx,components=components,
        confidence={"missing_industry_share":missing_industry/gross},unlevered_score=unlevered)

def stress_score(ctx):
    """F2=200*max(nonnegative scenario loss)/positive equity, capped at 100.

    Up/down market and FX paths explicitly cover signed positions and debt.
    Scenarios are illustrations, not exhaustive maxima or assigned probabilities.
    One-company failure is not applied to diversified-fund wrappers. A short
    issuer +100% path is illustrative; losses of a short can exceed this.
    """
    boundary=_boundary("F2",ctx)
    if boundary:return boundary
    rows=ctx["positions"];base=ctx["base"]
    foreign=sorted({c for p in rows for c,w in p["currency_exposures"].items() if c!=base and w}
                   |{a["currency"] for a in ctx["accounts"] if a["cash"] and a["currency"]!=base})
    fxpaths=[("fx_fixed",{})]
    for sign in (-1,1):
        suffix="down" if sign<0 else "up"
        fxpaths.append((f"all_foreign_{suffix}",{c:sign*.2 for c in foreign}))
        fxpaths.extend((f"{c}_{suffix}",{c:sign*.2}) for c in foreign)
    scenarios=[]
    for market_sign in (-1,0,1):
        for fxlabel,fxshock in fxpaths:
            if market_sign==0 and not fxshock:continue
            pnl=0
            for p in rows:
                market=market_sign*STRESS_LOSS[_focus(p)]
                fx=sum(weight*fxshock.get(currency,0) for currency,weight in p["currency_exposures"].items())
                pnl+=p["value"]*((1+market)*(1+fx)-1)
            pnl+=sum(a["cash"]*fxshock.get(a["currency"],0) for a in ctx["accounts"])
            scenarios.append({"name":f"market_{market_sign}_{fxlabel}","pnl":pnl,"loss":max(0,-pnl)})
    issuers=defaultdict(float)
    for p in rows:
        if _focus(p)=="single_equity":issuers[p.get("issuer") or p["symbol"]]+=p["value"]
    for issuer,value in issuers.items():
        for sign in (-1,1):
            pnl=value*sign
            scenarios.append({"name":f"issuer_{issuer}_{sign}","pnl":pnl,"loss":max(0,-pnl)})
    worst=max(scenarios,key=lambda s:s["loss"],default={"name":"none","loss":0,"pnl":0})
    loss_fraction=worst["loss"]/ctx["equity"]
    return _output("F2",200*loss_fraction,ctx,components={"maximum_stress_loss":worst["loss"],
        "maximum_stress_loss_fraction":loss_fraction},worst_scenario=worst["name"],scenarios=scenarios)

def factor_score(ctx):
    """F3=200*sqrt(sum(independent factor dollar exposures squared))/equity.

    The model is positive semidefinite by construction. Coefficients are assumed,
    not calibrated annual volatility estimates. The reported sigma is an assumed
    annual-risk proxy, never a claim about observed portfolio volatility.
    """
    boundary=_boundary("F3",ctx)
    if boundary:return boundary
    factors=defaultdict(float);base=ctx["base"]
    for p in ctx["positions"]:
        focus=_focus(p);equity_beta,rate_beta,residual=FACTOR_LOADINGS[focus];value=p["value"]
        factors["global_equity"]+=value*equity_beta*.18
        factors["rates"]+=value*rate_beta*.08
        issuer=p.get("issuer") or p["symbol"]
        if p.get("diversified"):
            residual_key=f"focus:{focus}:{p.get('industry','')}" if focus=="sector_equity" else f"focus:{focus}"
        else:residual_key=f"issuer:{issuer}"
        factors[residual_key]+=value*residual
        for currency,weight in p["currency_exposures"].items():
            if currency!=base:factors[f"fx:{currency}"]+=value*weight*.12
    for a in ctx["accounts"]:
        if a["currency"]!=base:factors[f"fx:{a['currency']}"]+=a["cash"]*.12
    variance=sum(x*x for x in factors.values());sigma=math.sqrt(variance)/ctx["equity"]
    return _output("F3",200*sigma,ctx,components={"assumed_sigma":sigma},
        factor_dollar_exposures=dict(factors),factor_variance_shares={k:v*v/variance if variance else 0 for k,v in factors.items()})

def evaluate(state):
    """Evaluate all four proposed models, preserving unavailable inputs."""
    ctx,gaps=_prepare(state)
    if gaps:return {model:{"model":model,"name":name,"version":VERSION,"status":"unavailable",
                          "score":None,"raw_score":None,"gaps":gaps} for model,name in NAMES.items()}
    f1=repaired_heuristic(ctx);f2=stress_score(ctx);f3=factor_score(ctx)
    f4=_output("F4",.7*f2["raw_score"]+.3*f3["raw_score"],ctx,
               components={"stress":.7*f2["raw_score"],"factor":.3*f3["raw_score"]})
    return {"F1":f1,"F2":f2,"F3":f3,"F4":f4}

def evaluate_accounts(state):
    return {str(a["id"]):evaluate({**state,"accounts":[a],"positions":[p for p in state["positions"]
                if str(p["account_id"])==str(a["id"])]}) for a in state["accounts"]}

if __name__=="__main__":
    import json,sys
    fixture=json.load(open(sys.argv[1],encoding="utf-8"))
    print(json.dumps({"models":evaluate(fixture),"accounts":evaluate_accounts(fixture)},ensure_ascii=False,indent=2))
