"""Normalize a read-only capture; retain actual JS model for exact reproduction."""
from collections import Counter
from copy import deepcopy
from datetime import date
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
source = (ROOT / 'web/app.js').read_text()
names = ['sum', 'normalizedField', 'normalizedAmount', 'updateFxRates', 'setCoreFxRates',
         'isEquityCompAccount', 'portfolioAccounts', 'isEquityCompHolding', 'portfolioItems',
         'accountCashBalance', 'accountCashValue', 'accountRiskCashValue', 'accountRecordForHolding',
         'assetRiskFactor', 'clamp', 'derivativeHolding', 'diversifiedFund', 'industryLabel',
         'issuerLabel', 'countryLabel', 'economicCurrencyExposure', 'volatilityProxy',
         'personHorizonYears', 'accountHorizonYears', 'riskScoreForItems', 'portfolioRiskSnapshot',
         'riskAllocationForItems', 'riskAllocationBand',
         'cleanSourceLabel', 'transactionCashImpact', 'ageFromBirthDate']
functions = []
for name in names:
    start = source.index(f'function {name}(')
    end = re.search(r'^}', source[start:], re.M).end()
    functions.append(source[start:start+end])
js = "const fs=require('fs');const state={baseCurrency:'ILS',fxRates:{},coreFxRates:{},bannerFxRates:{},localAccounts:[],localTransactions:[],language:'en'};\nconst fmt=(n,d=1)=>Number(n).toFixed(d);const optionLabel=s=>s;\n" + '\n'.join(functions)
js += r'''
function summarize(context) {
  state.baseCurrency=context.base_currency;state.localAccounts=context.accounts;
  state.localTransactions=context.transactions||[];setCoreFxRates(context.fx);
  const items=portfolioItems(context.items);
  const snapshot=portfolioRiskSnapshot(items);
  const clean=r=>{const {position_risks,...other}=r;return other;};
  const accounts=snapshot.accounts.map(a=>({...a,risk:clean(a.risk)}));
  const nav=sum(accounts.map(a=>a.value))||1;
  const w=sum(accounts.map(a=>a.risk.score*a.value/nav));
  const c=snapshot.total;
  const raw=c.net_equity<=0&&(items.length||c.cash_debt>0)?100:
    .75*Math.round(c.unlevered_score+(c.components.borrowing||0))+.25*w;
  return {score:c.score,raw_score:raw,combined_score:Math.round(c.unlevered_score+(c.components.borrowing||0)),
    weighted_accounts:w,total:clean(c),accounts,positions:items.map(i=>({
      account_id:i.holding.account_id,symbol:i.holding.symbol,value:normalizedField(i,'market_value'),
      asset_factor:assetRiskFactor(i),volatility_proxy:volatilityProxy(i),derivative:derivativeHolding(i),
      diversified:diversifiedFund(i),industry:industryLabel(i),country:countryLabel(i),
      currency_exposure:economicCurrencyExposure(i)}))};
}
function stateContext(s) {
  const rate=c=>c===s.base_currency?1:s.fx_rates[c];
  return {base_currency:s.base_currency,fx:{quotes:Object.entries(s.fx_rates).filter(([c])=>c!==s.base_currency).map(([c,r])=>({pair:c+'/'+s.base_currency,quote:{rate:r}}))},
    accounts:s.accounts.map(a=>({id:a.id,type:a.type,currency:a.currency,initial_cash:a.cash/rate(a.currency),
      account_id:a.label,management_company:a.label,persons:a.horizon_years==null?[]:[{age:40,retire_age:40+a.horizon_years}]})),
    items:s.positions.filter(p=>Math.abs(p.value)>1e-9).map(p=>{
      let item=JSON.parse(JSON.stringify(p.item||{}));
      item.holding={...(item.holding||{}),symbol:p.symbol,account_id:p.account_id,asset_class:p.asset_class,
        currency:p.currency,market_value:p.value/rate(p.currency),quantity:p.quantity??1,country:p.country};
      item.industry=p.industry;item.missing=p.missing||[];
      item.exposure_profile={...(item.exposure_profile||{}),asset_focus:p.asset_focus||undefined,
        fx_basis:'reported',currency_exposures:Object.entries(p.currency_exposures).map(([currency,f])=>({currency,percent:f*100})),
        fx_reference_currency:undefined};
      // Keep the captured range ratio fixed for forward composition experiments.
      // Observed market shocks change values, not an invented return history.
      return item;
    })};
}
const input=JSON.parse(fs.readFileSync(0,'utf8'));
if(input.states) process.stdout.write(JSON.stringify(input.states.map(s=>{const r=summarize(stateContext(s));if(input.slim){delete r.positions;for(const a of r.accounts)delete a.allocation;}return r;})));
else process.stdout.write(JSON.stringify(summarize(input)));
'''
(HERE / 'current_model.js').write_text(js)
s = json.loads((HERE / 'input.json').read_text())
fx_rows = [r for r in s['fx_saved'] if r['provider']=='frankfurter_fx']
rates={'ILS':1.0,**{r['pair'].split('/')[0]:r['quote']['rate'] for r in fx_rows if r['pair'].endswith('/ILS')}}
accounts=[a for a in s['accounts'] if a['type']!='ESOP']
ids={a['id'] for a in accounts}
items=[i for i in s['items'] if i['holding']['account_id'] in ids and i['holding']['asset_class'] not in {'RSU','EMPLOYEE_STOCK_OPTION','STOCK_OPTION'}]
txs=[t for t in s['transactions'] if t['account_db_id'] in ids]
raw={(i['holding']['account_id'],i['holding']['symbol'],i['holding']['stock_market']):i for i in s['ledger_items']}
differences=[];valuation_audit=[]
for i in items:
    h=i['holding']; r=raw[(h['account_id'],h['symbol'],h['stock_market'])]['holding']
    for field in ['quantity','cost_basis','asset_class','currency']:
        if h.get(field)!=r.get(field):differences.append({'symbol':h['symbol'],'field':field,'saved':h.get(field),'ledger':r.get(field)})
    marks=[q for q in i.get('price_ranges',{}).values() if q.get('current_date') and q.get('current') is not None]
    mark=max(marks,key=lambda q:q['current_date']) if marks else {}
    expected=h['quantity']*mark['current'] if mark else None
    valuation_audit.append({'symbol':h['symbol'],'account_id':h['account_id'],'currency':h['currency'],
      'quantity':h['quantity'],'value':h['market_value'],'unit_price':mark.get('current'),
      'price_date':mark.get('current_date'),'quantity_price_difference':h['market_value']-expected if expected is not None else None})
if differences:raise ValueError(f'Position identity mismatch {differences}')
context={'base_currency':'ILS','accounts':accounts,'transactions':txs,'items':items,
         'fx':{'quotes':[{'pair':r['pair'],'quote':r['quote']} for r in fx_rows]}}
(HERE/'context.json').write_text(json.dumps(context,ensure_ascii=False))
current=json.loads(subprocess.check_output(['node',str(HERE/'current_model.js')],input=json.dumps(context).encode()))
(HERE/'current_baseline.json').write_text(json.dumps(current,ensure_ascii=False,indent=2))
positions=[]
for i,p in zip(items,current['positions']):
    h=i['holding']; profile=i.get('exposure_profile') or {};focus=profile.get('asset_focus','')
    if h['asset_class']=='BOND' and (i.get('market_data') or {}).get('provider')=='treasury_direct':focus='government_bond'
    positions.append({'account_id':h['account_id'],'symbol':h['symbol'],'issuer':h['symbol'],'value':p['value'],
      'asset_class':h['asset_class'],'asset_focus':focus,'industry':p['industry'],'sector':h.get('sector',''),
      'country':p['country'],'currency':h['currency'],'quantity':h['quantity'],'asset_factor':p['asset_factor'],
      'currency_exposures':{a['currency']:a['percent']/100 for a in p['currency_exposure']['allocations']},
      'unknown_currency':p['currency_exposure']['unknownPercent']/100,'volatility_proxy':p['volatility_proxy'],
      'derivative':p['derivative'],'diversified':p['diversified'],'missing':i.get('missing',[]),'item':i})
def delta(t):
    v=t['quantity']*t['price']
    return -v if t['action'] in {'BUY','CASH_OUT','FEE'} else v if t['action'] in {'SELL','SHORT','DIVIDEND','INTEREST','CASH_IN'} else 0
normalized_accounts=[]
for a in accounts:
    cash=a['initial_cash']+math.fsum(delta(t) for t in txs if t['account_db_id']==a['id'])
    horizon=min([p['retire_age']-p['age'] for p in a.get('persons',[]) if p.get('age') is not None and p.get('retire_age') is not None],default=15 if a['type']=='Long-Term Savings' else None)
    native=math.fsum(i['holding']['market_value'] for i in items if i['holding']['account_id']==a['id'])
    normalized_accounts.append({'id':a['id'],'label':a['management_company']+' · …'+a['account_id'][-4:],
      'cash':cash*rates[a['currency']],'cash_native':cash,'currency':a['currency'],'horizon_years':horizon,'type':a['type'],
      'securities_native':native,'securities_value':native*rates[a['currency']],
      'net_value':(native+cash)*rates[a['currency']]})
state={'base_currency':'ILS','fx_rates':rates,'positions':positions,'accounts':normalized_accounts}
(HERE/'snapshot.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
parity=json.loads(subprocess.check_output(['node',str(HERE/'current_model.js')],input=json.dumps({'states':[state]}).encode()))[0]
assert parity['score']==current['score']
assert [a['risk']['score'] for a in parity['accounts']]==[a['risk']['score'] for a in current['accounts']]
funds=s['tables']['funds'];fund_total=math.fsum(f['amount'] for f in funds)
audit={'captured_at':s['captured_at'],'fx':fx_rows,'source_signature':s['source_signature'],
       'cache_signature_matches_ledger':s['cache_signature_matches_ledger'],
       'positions_match_current_ledger':not differences,'position_count':len(positions),'distinct_symbols':len({p['symbol'] for p in positions}),
       'valuation_audit':valuation_audit,'current_accounts':normalized_accounts,
       'portfolio_value':math.fsum(a['net_value'] for a in normalized_accounts),
       'securities_value':math.fsum(p['value'] for p in positions),'cash':math.fsum(a['cash'] for a in normalized_accounts),
       'debt':math.fsum(max(0,-a['cash']) for a in normalized_accounts),'separate_funds':funds,'separate_funds_total':fund_total,
       'combined_wealth_excluding_esop':math.fsum(a['net_value'] for a in normalized_accounts)+fund_total,
       'js_source_sha256':hashlib.sha256(source.encode()).hexdigest(),
       'cash_currency_mismatches':[t['id'] for t in txs if delta(t)!=0 and t['currency']!=next(a['currency'] for a in accounts if a['id']==t['account_db_id'])],
       'future_transactions':[t['id'] for t in txs if t['trade_date']>'2026-11-13'],
       'native_to_normalized_risk_parity':True}
(HERE/'value_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps({key:value for key,value in audit.items() if key in {'position_count','distinct_symbols','portfolio_value','securities_value','cash','debt','separate_funds_total','combined_wealth_excluding_esop','cash_currency_mismatches','future_transactions'}}))
print('Current risk',current['score'],'accounts',[(a['account'],a['risk']['score']) for a in current['accounts']])
print('Account totals',[(a['label'],a['cash_native'],a['net_value']) for a in normalized_accounts])
print('Price dates',dict(Counter(v['price_date'] for v in valuation_audit)))
